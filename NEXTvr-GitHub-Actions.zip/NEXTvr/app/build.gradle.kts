plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.nextvr.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.nextvr.app"
        minSdk = 26; targetSdk = 34
        versionCode = 1; versionName = "0.1.0"
    }
    buildTypes { release { isMinifyEnabled = true
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

// MediaPipe Hand Landmarker model. Downloaded on first build when internet is available.
// It is optional at runtime: without it, gaze/touch controls remain available.
val handLandmarkerModel = layout.projectDirectory.file("src/main/assets/hand_landmarker.task")
val downloadHandLandmarkerModel by tasks.registering {
    outputs.file(handLandmarkerModel)
    doLast {
        val model = handLandmarkerModel.asFile
        if (!model.exists() || model.length() < 1_000_000L) {
            model.parentFile.mkdirs()
            val temp = java.io.File(model.parentFile, model.name + ".download")
            try {
                val url = java.net.URL("https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task")
                val connection = url.openConnection().apply { connectTimeout = 20_000; readTimeout = 90_000 }
                connection.getInputStream().use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
                if (temp.length() < 1_000_000L) error("MediaPipe model download is incomplete (${temp.length()} bytes)")
                if (model.exists()) model.delete()
                if (!temp.renameTo(model)) error("Could not move downloaded model into assets")
                println("MediaPipe Hand Landmarker model downloaded.")
            } catch (e: Exception) {
                println("WARNING: MediaPipe model download failed: ${e.message}")
                println("APK build will continue; hand tracking needs hand_landmarker.task in app/src/main/assets/.")
            } finally { if (temp.exists()) temp.delete() }
        } else println("MediaPipe model already exists; download skipped.")
    }
}
// Model indirmesi artik otomatik preBuild gorevi degil.
// Isteyen daha sonra :app:downloadHandLandmarkerModel gorevini ayri calistirabilir.

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}
