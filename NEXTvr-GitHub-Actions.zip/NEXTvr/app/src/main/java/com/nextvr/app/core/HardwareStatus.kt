package com.nextvr.app.core
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import androidx.core.content.ContextCompat

enum class Level { READY, LIMITED, MISSING }
data class Item(val label: String, val level: Level, val detail: String)

/** Reads real device capabilities; nothing is reported ready without being checked. */
object HardwareStatus {
    fun read(c: Context): List<Item> {
        val sm = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
        val rot = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null
        val pm = c.packageManager
        val cam = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
        val camPerm = ContextCompat.checkSelfPermission(c, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        @Suppress("DEPRECATION")
        val model = pm.let { c.assets.list("")?.contains("hand_landmarker.task") == true }
        val rate = (c.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.refreshRate
        val webView = runCatching { android.webkit.WebView.getCurrentWebViewPackage() }.getOrNull()
        return listOf(
            Item("Sensörler", if (gyro && rot) Level.READY else if (rot) Level.LIMITED else Level.MISSING,
                if (gyro && rot) "Jiroskop + rotasyon" else if (rot) "Sadece rotasyon vektörü (3DoF sınırlı)" else "Baş takibi için sensör yok"),
            Item("Kamera", if (!cam) Level.MISSING else if (camPerm) Level.READY else Level.LIMITED,
                if (!cam) "Kamera yok" else if (camPerm) "İzin verildi" else "İzin gerekli"),
            Item("El takibi", if (!cam || !model) Level.MISSING else if (camPerm) Level.READY else Level.LIMITED,
                if (!cam) "Kamera yok" else if (!model) "Model dosyası yok (assets/hand_landmarker.task)" else if (camPerm) "Model hazır" else "Model hazır, kamera izni gerekli"),
            Item("Tarayıcı", if (webView != null) Level.READY else Level.MISSING,
                if (webView != null) "WebView ${webView.versionName}" else "Sistem WebView bulunamadı"),
            Item("WebXR", Level.MISSING, "Gerçek runtime kontrolü Aşama 6'da"),
            Item("Ekran", Level.READY, "${rate.toInt()} Hz")
        )
    }
}
