package com.nextvr.app.hand
import androidx.compose.runtime.*

/**
 * Hand calibration wizard. Real checks from the live camera/model:
 * hand found, distance (hand size vs frame), lighting (camera luma), frame edges, model confidence.
 * Then measures this user's open-hand and pinch ratios and derives the pinch threshold.
 * Camera ANGLE cannot be measured reliably; the "in frame / not on the edge" check is its practical proxy.
 */
class HandCalibration {
    var text by mutableStateOf("Başlat'a bas. El takibi açık olmalı.")
        private set
    var onDone: (Float) -> Unit = {}
    private var step = 0            // 0 idle, 1 position, 2 open hand, 3 pinch, 4 done
    private var okSince = 0L
    private var lastTs = 0L
    private var sum = 0f; private var n = 0
    private var openRatio = 0.9f
    private val holdMs = 1500L

    fun start() { step = 1; okSince = 0L; sum = 0f; n = 0; text = "Hazırlanıyor…" }
    fun cancel() { step = 0; text = "Başlat'a bas. El takibi açık olmalı." }

    private fun mark(b: Boolean) = if (b) "✓" else "✗"
    private fun bar(frac: Float): String { val k = (frac * 5).toInt().coerceIn(0, 5); return "▰".repeat(k) + "▱".repeat(5 - k) }

    fun update(s: HandSnapshot, luma: Float, trackingOn: Boolean, now: Long) {
        if (step == 0 || step == 4) return
        if (!trackingOn) { set("El takibi kapalı veya model/kamera hazır değil.\nAyarlar'dan El takibi'ni aç."); return }
        val vis = s.visible && now - s.ts < 300
        val distOk = vis && s.size in 0.12f..0.38f
        val lumaOk = luma in 55f..215f
        val frameOk = vis && !s.edge
        val confOk = vis && s.score >= 0.7f
        val all = vis && distOk && lumaOk && frameOk && confOk
        val checks = "${mark(vis)} El algılandı\n${mark(distOk)} Mesafe (${if (!vis) "-" else if (s.size < 0.12f) "yaklaştır" else if (s.size > 0.38f) "uzaklaştır" else "uygun"})\n" +
            "${mark(lumaOk)} Işık (${if (luma < 0f) "-" else if (luma < 55f) "yetersiz" else if (luma > 215f) "çok parlak" else "uygun"})\n" +
            "${mark(frameOk)} Kadraj (kenara değmesin)\n${mark(confOk)} Algılama güveni"
        val fresh = s.ts != lastTs; lastTs = s.ts
        when (step) {
            1 -> {
                if (all) { if (okSince == 0L) okSince = now } else okSince = 0L
                val f = if (okSince == 0L) 0f else ((now - okSince) / holdMs.toFloat()).coerceIn(0f, 1f)
                set("1/3 Konum — elini kameraya göster ve sabit tut\n$checks\n${bar(f)}")
                if (f >= 1f) { step = 2; okSince = 0L; sum = 0f; n = 0 }
            }
            2 -> {
                val good = all && s.ratio > 0.55f
                if (good) { if (okSince == 0L) okSince = now; if (fresh) { sum += s.ratio; n++ } } else { okSince = 0L; sum = 0f; n = 0 }
                val f = if (okSince == 0L) 0f else ((now - okSince) / holdMs.toFloat()).coerceIn(0f, 1f)
                set("2/3 Açık el — parmakları aç, sabit tut\n$checks\n${bar(f)}")
                if (f >= 1f && n > 0) { openRatio = sum / n; step = 3; okSince = 0L; sum = 0f; n = 0 }
            }
            3 -> {
                val good = vis && confOk && s.ratio < 0.5f
                if (good) { if (okSince == 0L) okSince = now; if (fresh) { sum += s.ratio; n++ } } else { okSince = 0L; sum = 0f; n = 0 }
                val f = if (okSince == 0L) 0f else ((now - okSince) / holdMs.toFloat()).coerceIn(0f, 1f)
                set("3/3 Pinch — başparmak ve işaret parmağını birleştir, tut\n${mark(vis)} El algılandı\n${mark(confOk)} Algılama güveni\n${bar(f)}")
                if (f >= 1f && n > 0) {
                    val pinchRatio = sum / n
                    val on = (pinchRatio + 0.35f * (openRatio - pinchRatio)).coerceIn(0.18f, 0.38f)
                    step = 4
                    set("✓ Kalibrasyon tamam\nAçık el: %.2f   Pinch: %.2f\nPinch eşiği: %.2f (kaydedildi)".format(openRatio, pinchRatio, on))
                    onDone(on)
                }
            }
        }
    }
    private fun set(t: String) { if (t != text) text = t }
}
