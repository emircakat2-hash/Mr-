package com.nextvr.app
import android.app.Application
import com.nextvr.app.data.SettingsStore
class NextVrApp : Application() {
    val settings by lazy { SettingsStore(this) }
}
