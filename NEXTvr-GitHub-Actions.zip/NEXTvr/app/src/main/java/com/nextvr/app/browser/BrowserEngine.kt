package com.nextvr.app.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.app.Presentation
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.MotionEvent
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The NEXTvr browser, as in the NEXTvr-BE app: every tab is a real WebView that lives on a private
 * virtual display owned by the app. The display draws into an [ImageReader]; each new picture is
 * copied to a bitmap that the VR screen paints into both eyes. Touches and typing from gaze, hands
 * or the screen are turned into Android touch events on that display (see [touch], [tap], [type]).
 *
 * Everything that touches a WebView runs on the main thread. The picture is copied on its own thread.
 */
class BrowserEngine(private val activity: Activity) {
    companion object {
        /** The page's size in pixels and its density: 280 dpi reads like a tablet at arm's length in VR. */
        const val W = 1600
        const val H = 1000
        private const val DPI = 280
        /** Touch action meaning "a click": press and release at one place. */
        const val TAP = -1
        private const val FRAME_GAP_MS = 22L
        private const val DARK_BAR = true
        private const val TAG = "NEXTvr-Browser"
        private const val OWN_PAGES = "file:///android_asset/browser/"
    }

    /** A tab: its own WebView (built when the tab is first shown), where it is and what it is called. */
    private class Tab(var view: WebView?, @Volatile var url: String, @Volatile var title: String = "", val desktop: Boolean = false)

    // ---- what the VR screen reads (Compose state; every change redraws the window)
    /** The newest page picture; the bitmap may be wider than [W] (row padding): draw only W x H of it. */
    @Volatile var front: Bitmap? = null; private set
    var frameTick by mutableIntStateOf(0); private set
    var bar by mutableStateOf<ImageBitmap?>(null); private set
    var tabTitles by mutableStateOf<List<String>>(emptyList()); private set
    var activeTab by mutableIntStateOf(0); private set
    var running by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var shift by mutableStateOf(false)
    private var keyboardFlag by mutableStateOf(false)
    /** The address field while it is being typed into (the VR keyboard is up); null otherwise. */
    private var editing by mutableStateOf<String?>(null)

    /** True while the VR keyboard should be up: an address is being typed, or a page text field has focus. */
    val keyboardUp: Boolean get() = keyboardFlag || editing != null

    // ---- internals
    private val main = Handler(Looper.getMainLooper())
    private val tabs = CopyOnWriteArrayList<Tab>()
    private var active = 0
    private val currentUrl: String get() = tabs.getOrNull(active)?.url ?: BrowserData.HOME
    private val currentTitle: String get() = tabs.getOrNull(active)?.title.orEmpty()
    private val webView: WebView? get() = tabs.getOrNull(active)?.view

    private var display: VirtualDisplay? = null
    private var presentation: Presentation? = null
    @Volatile private var reader: ImageReader? = null
    private var frameThread: HandlerThread? = null
    private var frameHandler: Handler? = null
    private val copyQueued = AtomicBoolean(false)
    private var lastCopy = 0L
    private var back: Bitmap? = null
    private var downTime = 0L

    private fun ownPage() = currentUrl.startsWith(OWN_PAGES)

    // ------------------------------------------------------------------ lifecycle

    /** Opens the display and the saved tabs. Main thread. */
    fun start() {
        if (running) return
        error = null
        try {
            val thread = HandlerThread("NEXTvr-browser-frames").also { it.start() }
            frameThread = thread
            frameHandler = Handler(thread.looper)
            val r = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2)
            r.setOnImageAvailableListener({ queueCopy() }, frameHandler)
            reader = r
            // A private display owned by NEXTvr: no special permission is needed for our own content.
            val vd = activity.getSystemService(DisplayManager::class.java)
                .createVirtualDisplay("NEXTvr Browser", W, H, DPI, r.surface, 0)
                ?: throw IllegalStateException("Sanal ekran açılamadı")
            display = vd
            val (urls, saved) = BrowserData.savedTabs(activity)
            val list = urls.ifEmpty { listOf(BrowserData.HOME) }
            list.forEach { tabs += Tab(null, it) }
            presentation = Presentation(activity, vd.display).also { it.show() }
            running = true
            showTab(saved.coerceIn(0, tabs.size - 1))
            pendingOpen?.let { (u, wide) -> pendingOpen = null; addTab(u, wide) }
        } catch (e: Throwable) {
            Log.w(TAG, "start failed", e)
            error = "Tarayıcı başlatılamadı: ${e.message ?: e.javaClass.simpleName}"
            teardown(saveTabs = false)
        }
    }

    /** Closes everything; the tabs are remembered for the next [start]. Main thread. */
    fun stop() {
        if (!running && display == null) return
        teardown(saveTabs = true)
    }

    private fun teardown(saveTabs: Boolean) {
        if (saveTabs && tabs.isNotEmpty()) BrowserData.saveTabs(activity, tabs.map { it.url }, active)
        running = false
        try { presentation?.dismiss() } catch (_: Throwable) {}
        presentation = null
        tabs.forEach { try { it.view?.destroy() } catch (_: Throwable) {} }
        tabs.clear()
        active = 0
        try { display?.release() } catch (_: Throwable) {}
        display = null
        val r = reader; reader = null
        try { r?.close() } catch (_: Throwable) {}
        frameThread?.quitSafely(); frameThread = null; frameHandler = null
        front = null; back = null
        keyboardFlag = false; editing = null; shift = false
        bar = null; tabTitles = emptyList(); activeTab = 0
    }

    fun onPause() { tabs.forEach { it.view?.onPause() } }
    fun onResume() { webView?.onResume() }

    // ------------------------------------------------------------------ the picture

    private fun queueCopy() {
        if (!copyQueued.compareAndSet(false, true)) return
        val wait = (FRAME_GAP_MS - (SystemClock.uptimeMillis() - lastCopy)).coerceAtLeast(0L)
        frameHandler?.postDelayed({ copyLatest() }, wait)
    }

    /** Frame thread: the newest picture of the page into a bitmap (two bitmaps swap, so drawing never waits). */
    private fun copyLatest() {
        copyQueued.set(false)
        val r = reader ?: return
        val image = try { r.acquireLatestImage() } catch (_: Throwable) { null } ?: return
        try {
            val plane = image.planes[0]
            val stride = plane.rowStride / plane.pixelStride
            var target = back
            if (target == null || target.width != stride || target.height != image.height) {
                target = Bitmap.createBitmap(stride, image.height, Bitmap.Config.ARGB_8888)
            }
            plane.buffer.rewind()
            target.copyPixelsFromBuffer(plane.buffer)
            back = front
            front = target
            lastCopy = SystemClock.uptimeMillis()
            main.post { frameTick++ }
        } catch (e: Throwable) {
            Log.w(TAG, "frame copy failed", e)
        } finally {
            image.close()
        }
    }

    // ------------------------------------------------------------------ input

    /** Touch at 0..1 page coordinates: MotionEvent.ACTION_DOWN / MOVE / UP / CANCEL, or [TAP]. */
    fun pageTouch(action: Int, u: Float, v: Float) {
        if (action == TAP) { tap(u, v); return }
        touch(action, u, v)
    }

    fun tap(u: Float, v: Float) {
        touch(MotionEvent.ACTION_DOWN, u, v)
        main.postDelayed({ touch(MotionEvent.ACTION_UP, u, v) }, 60L)
    }

    private fun touch(action: Int, u: Float, v: Float) {
        main.post {
            val decor = presentation?.window?.decorView ?: return@post
            val now = SystemClock.uptimeMillis()
            if (action == MotionEvent.ACTION_DOWN) downTime = now
            val event = MotionEvent.obtain(downTime, now, action, u.coerceIn(0f, 1f) * W, v.coerceIn(0f, 1f) * H, 0)
            event.source = InputDevice.SOURCE_TOUCHSCREEN
            decor.dispatchTouchEvent(event)
            event.recycle()
        }
    }

    /** Half a page up (-1) or down (+1). */
    fun scroll(direction: Int) {
        main.post { webView?.let { it.scrollBy(0, direction * it.height / 2) } }
    }

    /** A key from the VR keyboard: text, or "backspace" / "enter". */
    fun type(key: String) {
        val typed = editing
        if (typed != null) {
            when (key) {
                "backspace" -> editing = typed.dropLast(1)
                "enter" -> {
                    editing = null
                    val url = BrowserData.addressFor(typed)
                    main.post { webView?.loadUrl(url) }
                }
                else -> if (typed.length < 400) editing = typed + key
            }
            refreshBar()
            return
        }
        val script = when (key) {
            "backspace" -> "window.__pxrType && __pxrType('', 1)"
            "enter" -> "window.__pxrType && __pxrType('\\n', 0)"
            else -> "window.__pxrType && __pxrType(${JSONObject.quote(key)}, 0)"
        }
        main.post { webView?.evaluateJavascript(script, null) }
    }

    fun hideKeyboard() {
        if (editing != null) { editing = null; refreshBar(); return }
        keyboardFlag = false
        main.post { webView?.evaluateJavascript("document.activeElement && document.activeElement.blur()", null) }
    }

    /** A button of the bar: "back", "forward", "reload", "home", "newtab", "tab:N", "closetab:N", "address", "bookmark". */
    fun toolbarAction(action: String) {
        main.post {
            val view = webView ?: return@post
            when {
                action == "back" -> if (view.canGoBack()) view.goBack()
                action == "forward" -> if (view.canGoForward()) view.goForward()
                action == "reload" -> view.reload()
                action == "home" -> view.loadUrl(BrowserData.HOME)
                action == "newtab" -> addTab(BrowserData.HOME)
                action == "address" -> startEditing()
                action == "bookmark" -> if (currentUrl.startsWith("http")) {
                    BrowserData.toggleBookmark(activity, currentUrl, currentTitle)
                    refreshBar()
                }
                action.startsWith("tab:") -> action.removePrefix("tab:").toIntOrNull()?.let { showTab(it) }
                action.startsWith("closetab:") -> action.removePrefix("closetab:").toIntOrNull()?.let { closeTab(it) }
                else -> Unit
            }
        }
    }

    private fun startEditing() { editing = ""; refreshBar() }

    // ------------------------------------------------------------------ tabs

    /** A web app of the store: a new tab with [url]; waits for [start] if the browser is not running yet. Any thread. */
    fun openUrl(url: String, desktop: Boolean = false) {
        main.post {
            if (!running) { pendingOpen = url to desktop; return@post }
            val same = if (url.startsWith("file:")) tabs.indexOfFirst { it.url == url } else -1
            if (same >= 0) showTab(same) else addTab(url, desktop)
        }
    }
    private var pendingOpen: Pair<String, Boolean>? = null

    private fun addTab(url: String, desktop: Boolean = false) {
        tabs += Tab(null, url, desktop = desktop)
        showTab(tabs.size - 1)
    }

    private fun showTab(index: Int) {
        val tab = tabs.getOrNull(index) ?: return
        val view = tab.view ?: buildWebView(tab.url, tab.desktop).also { tab.view = it }
        active = index
        presentation?.setContentView(view)
        keyboardFlag = false
        refreshBar()
    }

    /** Closes a tab; the last one is not closed but goes to the start page. */
    private fun closeTab(index: Int) {
        val tab = tabs.getOrNull(index) ?: return
        if (tabs.size == 1) { tab.view?.loadUrl(BrowserData.HOME); return }
        tabs.removeAt(index)
        tab.view?.destroy()
        showTab(if (active >= tabs.size) tabs.size - 1 else if (index < active) active - 1 else active)
    }

    private fun tabOf(view: WebView) = tabs.firstOrNull { it.view === view }

    // ------------------------------------------------------------------ the bar

    private fun addressText(): String {
        editing?.let { return it + "|" }
        val star = if (BrowserData.isBookmarked(activity, currentUrl)) "★ " else ""
        return star + when {
            currentUrl.startsWith("file:") -> BrowserChrome.PLACEHOLDER
            else -> Uri.parse(currentUrl).host?.removePrefix("www.") ?: currentUrl
        }
    }

    /** Redraws the bar and remembers the tabs. Safe from any thread. */
    private fun refreshBar() {
        if (Looper.myLooper() != Looper.getMainLooper()) { main.post { refreshBar() }; return }
        if (!running) return
        val titles = tabs.map { tab ->
            tab.title.ifEmpty { if (tab.url.startsWith("file:")) "Yeni Sekme" else Uri.parse(tab.url).host?.removePrefix("www.") ?: tab.url }
        }
        tabTitles = titles
        activeTab = active
        bar = BrowserChrome.drawBar(addressText(), titles, active, DARK_BAR).asImageBitmap()
        BrowserData.saveTabs(activity, tabs.map { it.url }, active)
    }

    // ------------------------------------------------------------------ the page

    /** Called from the page: text fields asking for the keyboard, and the start page's own calls. */
    private inner class Bridge {
        @JavascriptInterface fun keyboard(show: Boolean) { main.post { keyboardFlag = show } }
        @JavascriptInterface fun newTab(url: String) { if (ownPage()) main.post { addTab(BrowserData.addressFor(url)) } }

        // The start page only: its own list of shortcuts, bookmarks and switches.
        @JavascriptInterface fun homeData(): String = if (ownPage()) BrowserData.homeJson(activity) else "{}"
        @JavascriptInterface fun setDesktop(on: Boolean) { if (ownPage()) { BrowserData.setDesktop(activity, on); main.post { applySettings() } } }
        @JavascriptInterface fun setAdblock(on: Boolean) { if (ownPage()) BrowserData.setAdblock(activity, on) }
        @JavascriptInterface fun clearHistory() { if (ownPage()) BrowserData.clearHistory(activity) }
        @JavascriptInterface fun removeBookmark(url: String) { if (ownPage()) BrowserData.removeBookmark(activity, url) }
        @JavascriptInterface fun addShortcut(url: String, title: String) { if (ownPage()) BrowserData.addShortcut(activity, url, title) }
        @JavascriptInterface fun removeShortcut(url: String) { if (ownPage()) BrowserData.removeShortcut(activity, url) }
        @JavascriptInterface fun editAddress() { if (ownPage()) main.post { startEditing() } }
    }

    /** Desktop sites: a computer's browser name and a wide page; otherwise the phone's own. */
    private fun applySettings() {
        val view = webView ?: return
        val wide = BrowserData.desktop(activity)
        view.settings.userAgentString = if (wide) BrowserData.DESKTOP_AGENT else null
        view.settings.useWideViewPort = true
        view.settings.loadWithOverviewMode = wide
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebView(url: String, desktopTab: Boolean = false): WebView {
        return WebView(activity).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            // Only NEXTvr's own bundled pages are read from the APK; no other local files.
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webViewClient = object : WebViewClient() {
                override fun doUpdateVisitedHistory(view: WebView, address: String, isReload: Boolean) {
                    tabOf(view)?.url = address
                    refreshBar()
                }

                // The ad blocker: known ad and tracker hosts get an empty answer.
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    if (!BrowserData.adblock(activity) || !BrowserData.blocked(request.url.host)) return null
                    return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                }

                override fun onPageStarted(view: WebView, address: String?, favicon: Bitmap?) {
                    keyboardFlag = false
                    view.evaluateJavascript(PAGE_SCRIPT, null)
                }

                override fun onPageCommitVisible(view: WebView, address: String?) = view.evaluateJavascript(PAGE_SCRIPT, null)

                override fun onPageFinished(view: WebView, address: String?) {
                    view.evaluateJavascript(PAGE_SCRIPT, null)
                    val title = view.title.orEmpty()
                    tabOf(view)?.title = title
                    refreshBar()
                    if (address != null) BrowserData.visit(activity, address, title)
                }

                // A heavy page can take its renderer down. Without this Android would close all of
                // NEXTvr; instead the page comes back in a new WebView.
                override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                    Log.w(TAG, "page renderer gone, crash=${detail.didCrash()}")
                    main.post {
                        val tab = tabOf(view)
                        val fresh = buildWebView(tab?.url ?: currentUrl, tab?.desktop ?: false)
                        tab?.view = fresh
                        if (tab != null && tabs.indexOf(tab) == active) presentation?.setContentView(fresh)
                        view.destroy()
                    }
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                    if (message.message().startsWith("NEXTvr")) Log.i(TAG, message.message())
                    return false
                }
            }
            addJavascriptInterface(Bridge(), "NEXTvr")
            // Downloads go to Downloads/NEXTvr with the system's download manager.
            setDownloadListener { dlUrl, agent, disposition, mime, _ ->
                val name = URLUtil.guessFileName(dlUrl, disposition, mime)
                runCatching {
                    val request = DownloadManager.Request(Uri.parse(dlUrl))
                        .setMimeType(mime)
                        .addRequestHeader("User-Agent", agent)
                        .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(dlUrl) ?: "")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "NEXTvr/$name")
                    activity.getSystemService(DownloadManager::class.java).enqueue(request)
                    Toast.makeText(activity, "İndiriliyor: $name", Toast.LENGTH_SHORT).show()
                }.onFailure { Toast.makeText(activity, "İndirme başlatılamadı: $name", Toast.LENGTH_SHORT).show() }
            }
            val wide = desktopTab || BrowserData.desktop(activity)
            settings.userAgentString = if (wide) BrowserData.DESKTOP_AGENT else null
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = wide
            // Logins hand the session over between hosts.
            val cookies = CookieManager.getInstance()
            cookies.setAcceptCookie(true)
            cookies.setAcceptThirdPartyCookies(this, true)
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(false)
            loadUrl(url)
        }
    }

    /** Runs in every page: tells NEXTvr when a text field wants the VR keyboard, and types into it. */
    private val PAGE_SCRIPT = """
        (function() {
          if (window.__pxrType) return;
          var field = null;
          function editable(e) {
            if (!e || !e.tagName) return false;
            var tag = e.tagName.toLowerCase();
            if (tag == 'textarea') return !e.readOnly;
            if (tag == 'input') return ['text','search','email','url','tel','password','number',''].indexOf((e.type || '').toLowerCase()) >= 0 && !e.readOnly;
            return e.isContentEditable;
          }
          function pick(ev) { var t = ev.target; if (editable(t)) { field = t; NEXTvr.keyboard(true); } }
          document.addEventListener('focusin', pick, true);
          document.addEventListener('click', pick, true);
          document.addEventListener('focusout', function(ev) {
            if (ev.target === field) setTimeout(function() { if (document.activeElement !== field) NEXTvr.keyboard(false); }, 150);
          }, true);
          window.__pxrType = function(text, back) {
            var e = field || document.activeElement;
            if (!editable(e)) return;
            if (e.isContentEditable) {
              e.focus();
              if (back) document.execCommand('delete'); else if (text == '\n') document.execCommand('insertParagraph'); else document.execCommand('insertText', false, text);
              return;
            }
            if (text == '\n' && e.tagName.toLowerCase() != 'textarea') {
              var opts = {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true};
              var go = e.dispatchEvent(new KeyboardEvent('keydown', opts));
              e.dispatchEvent(new KeyboardEvent('keyup', opts));
              if (go && e.form) { if (e.form.requestSubmit) e.form.requestSubmit(); else e.form.submit(); }
              NEXTvr.keyboard(false);
              return;
            }
            var start = e.selectionStart, end = e.selectionEnd;
            if (start == null) { start = end = e.value.length; }
            if (back) { if (start == end && start > 0) start--; text = ''; }
            var proto = e.tagName.toLowerCase() == 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
            var setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
            setter.call(e, e.value.slice(0, start) + text + e.value.slice(end));
            try { e.setSelectionRange(start + text.length, start + text.length); } catch (x) {}
            e.dispatchEvent(new InputEvent('input', {bubbles: true, data: text, inputType: back ? 'deleteContentBackward' : 'insertText'}));
          };
        })();
    """.trimIndent()
}
