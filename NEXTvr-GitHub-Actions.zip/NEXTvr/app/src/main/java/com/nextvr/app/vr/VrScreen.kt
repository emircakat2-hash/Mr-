package com.nextvr.app.vr
import android.content.Context
import android.os.BatteryManager
import android.os.SystemClock
import com.nextvr.app.hand.HandTracker
import com.nextvr.app.browser.BrowserChrome
import com.nextvr.app.browser.BrowserEngine
import android.view.MotionEvent
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.nextvr.app.data.*
import com.nextvr.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.nextvr.app.hand.HandCalibration
import com.nextvr.app.store.WebApps
import kotlin.random.Random

/** Anything the user can look at / tap. label == null -> invisible hit area (window body). */
class Target(val id: String, val yaw: Float, val pitch: Float, val dist: Float, val w: Float, val h: Float,
             val label: String?, val active: Boolean = false,
             /** Turn of the window the target sits on (degrees), to find where inside it a hit landed. */
             val rot: Float = 0f,
             /** Own dwell time for gaze, ms (default: 450 for window bodies, the setting for buttons). */
             val dwell: Long? = null,
             /** A page: gets the whole touch (DOWN / MOVE / UP / CANCEL, or TAP) as 0..1 coordinates inside the target. */
             val touch: ((Int, Float, Float) -> Unit)? = null,
             /** A bar: gets a click as 0..1 coordinates inside the target. */
             val tapAt: ((Float, Float) -> Unit)? = null,
             val action: () -> Unit = {})

class Act(val recenter: () -> Unit, val exit: () -> Unit, val cyclePerf: () -> Unit,
          val cycleDwell: () -> Unit, val cycleMode: () -> Unit, val cycleHand: () -> Unit, val cycleCamera: () -> Unit, val hy: () -> Float, val hp: () -> Float,
          val calStart: () -> Unit, val calReset: () -> Unit, val openCal: () -> Unit, val browser: BrowserEngine,
          val home: HomeState, val store: StoreState, val webRemoved: (String) -> Unit, val launch: (HomeEntry) -> Unit)

private fun <T> next(list: List<T>, cur: T) = list[(list.indexOf(cur) + 1) % list.size]

fun buildTargets(d: DesktopState, s: Settings, a: Act): List<Target> {
    val out = mutableListOf<Target>()
    val vis = d.windows.filter { !it.minimized }
    vis.forEach { w ->
        out += Target("w:${w.id}", w.yaw, w.pitch, w.dist, w.w, w.h, null) { d.focus(w.id); if (!w.pinned) d.moving = w.id }
        if (w.kind == "browser") out += browserTargets(w, s, a.browser, d)
    }
    vis.forEach { w ->
        val sc = 2f / w.dist
        val r = Math.toRadians(w.rot.toDouble()); val cr = cos(r).toFloat(); val sr = sin(r).toFloat()
        // (dx right, dy up) in window space -> world angles, rotated with the window
        fun at(dx: Float, dy: Float) = Pair(w.yaw + (dx * cr - dy * sr) * sc, w.pitch + (dx * sr + dy * cr) * sc)
        fun ctl(i: Int, label: String, active: Boolean = false, act: () -> Unit) {
            val (yy, pp) = at(w.w / 2f - 2.6f - 4.2f * i, if (w.kind == "browser") w.h / 2f + 2.6f else w.h / 2f - 2.4f)
            out += Target("w:${w.id}:c$i", yy, pp, w.dist, 3.8f, 3.8f, label, active, action = act)
        }
        ctl(0, "✕") { d.close(w.id) }
        ctl(1, "▢") { d.toggleMax(w.id, a.hy(), a.hp()) }
        ctl(2, "—") { d.minimize(w.id) }
        ctl(3, "S", w.pinned) { d.togglePin(w.id) }
        ctl(4, "↔") { if (!w.pinned) d.moving = w.id }
        fun chip(id: String, dx: Float, dy: Float, cw: Float, label: String, act: () -> Unit) {
            val (yy, pp) = at(dx, dy)
            out += Target("w:${w.id}:$id", yy, pp, w.dist, cw, 5.5f, label, false, action = act)
        }
        when (w.kind) {
            "apps" -> APPS.forEachIndexed { i, app ->
                chip("app$i", ((i % 2) - 0.5f) * 13.5f, 2f - (i / 2) * 9f, 12.5f, app.name) { d.open(app.kind, a.hy(), a.hp()) }
            }
            "store" -> out += storeTargets(w, a.store, a, s)
            "settings" -> {
                val cx = w.w / 4f; val cw = w.w / 2f - 3f
                chip("perf", -cx, 3.5f, cw, "Profil: ${s.performance}") { a.cyclePerf() }
                chip("dwell", -cx, -3f, cw, "Gaze: ${s.dwellMs} ms") { a.cycleDwell() }
                chip("mode", -cx, -9.5f, cw, "Mod: ${s.vrMode}") { a.cycleMode() }
                chip("hand", cx, 3.5f, cw, "El takibi: ${if (s.handTracking) "açık" else "kapalı"}") { a.cycleHand() }
                chip("cam", cx, -3f, cw, "Kamera: ${if (s.camera == "front") "ön" else "arka"}") { a.cycleCamera() }
                chip("cal", cx, -9.5f, cw, "Kalibrasyon") { a.openCal() }
            }
            "handcal" -> {
                val cx = w.w / 4f; val cw = w.w / 2f - 3f
                chip("start", -cx, -(w.h / 2f - 4.5f), cw, "Başlat / Yeniden") { a.calStart() }
                chip("reset", cx, -(w.h / 2f - 4.5f), cw, "Varsayılan (%.2f)".format(s.pinchOn)) { a.calReset() }
            }
        }
    }
    // Top bar (world anchored)
    listOf("Merkez" to a.recenter,
        "Ortam: ${ENVS[d.env]}" to { d.env = (d.env + 1) % ENVS.size },
        "Düzen: ${LAYOUTS[d.layout]}" to { d.layout = (d.layout + 1) % LAYOUTS.size; d.applyLayout(d.layout, a.hy()) },
        "Çık" to a.exit
    ).forEachIndexed { i, (l, act) -> out += Target("top$i", (i - 1.5f) * 17f, 30f, 2f, 16f, 5.5f, l, false, action = act) }
    // Browser keyboard (world anchored under the browser window); it takes the dock's place
    val browserWin = vis.lastOrNull { it.kind == "browser" }
    val keyboardUp = browserWin != null && a.browser.keyboardUp
    if (keyboardUp) out += keyboardTargets(browserWin!!, s, a.browser)
    // Dock (world anchored; the keyboard takes its place) and, above it, the library when open.
    // Targets later in the list win, so the library comes last.
    if (!keyboardUp) out += dockTargets(a.home, a, d)
    if (a.home.libraryOpen) out += libraryTargets(a.home, a)
    return out
}

/** A point (dx right, dy up, in the window's own degrees) of a window, as world angles; turns with the window. */
internal fun windowPoint(w: Win, dx: Float, dy: Float): Pair<Float, Float> {
    val sc = 2f / w.dist
    val r = Math.toRadians(w.rot.toDouble()); val cr = cos(r).toFloat(); val sr = sin(r).toFloat()
    return Pair(w.yaw + (dx * cr - dy * sr) * sc, w.pitch + (dx * sr + dy * cr) * sc)
}

/**
 * The browser window's parts, in the order they must be hit: the tab strip's empty part (moves the
 * window), the tabs and +, the toolbar row, the page, and two scroll buttons beside the window.
 */
private fun browserTargets(w: Win, s: Settings, b: BrowserEngine, d: DesktopState): List<Target> {
    val out = mutableListOf<Target>()
    val barH = w.w * BrowserChrome.BAR_H / BrowserChrome.BAR_W
    val rowH = barH / 2f
    val top = w.h / 2f
    val n = b.tabTitles.size
    val dwell = 1000L
    fun at(dx: Float, dy: Float) = windowPoint(w, dx, dy)

    at(0f, top - rowH / 2f).let { (y, p) -> out += Target("w:${w.id}", y, p, w.dist, w.w, rowH, null, rot = w.rot) { d.focus(w.id); if (!w.pinned) d.moving = w.id } }
    if (n > 0) {
        val (u0, u1) = BrowserChrome.tabsSpan(n)
        at(((u0 + u1) / 2f - 0.5f) * w.w, top - rowH / 2f).let { (y, p) ->
            out += Target("w:${w.id}:tabs", y, p, w.dist, (u1 - u0) * w.w, rowH, null, rot = w.rot, dwell = dwell,
                tapAt = { u, v -> BrowserChrome.barAction(u0 + u * (u1 - u0), v * 0.5f, n)?.let { b.toolbarAction(it) } })
        }
    }
    at(0f, top - rowH * 1.5f).let { (y, p) ->
        out += Target("w:${w.id}:bar", y, p, w.dist, w.w, rowH, null, rot = w.rot, dwell = dwell,
            tapAt = { u, v -> BrowserChrome.barAction(u, 0.5f + v * 0.5f, n)?.let { b.toolbarAction(it) } })
    }
    at(0f, -barH / 2f).let { (y, p) ->
        // Reading must not click: a page needs a long look (twice the dwell, at least 1.5 s).
        out += Target("w:${w.id}:page", y, p, w.dist, w.w, w.h - barH, null, rot = w.rot,
            dwell = maxOf(1500L, dwell * 2), touch = { act, u, v -> b.pageTouch(act, u, v) })
    }
    at(w.w / 2f + 2.8f, 4.5f).let { (y, p) -> out += Target("w:${w.id}:up", y, p, w.dist, 3.8f, 3.8f, "▲", false, action = { b.scroll(-1) }) }
    at(w.w / 2f + 2.8f, -4.5f).let { (y, p) -> out += Target("w:${w.id}:down", y, p, w.dist, 3.8f, 3.8f, "▼", false, action = { b.scroll(1) }) }
    return out
}

private class KeyDef(val id: String, val label: String, val width: Float = 4.6f, val active: Boolean = false, val act: () -> Unit)

/** The VR keyboard (Turkish Q), under the browser window; it types into the address or the page's text field. */
private fun keyboardTargets(w: Win, s: Settings, b: BrowserEngine): List<Target> {
    val tr = java.util.Locale.forLanguageTag("tr")
    val out = mutableListOf<Target>()
    val top = w.pitch - w.h / 2f * (2f / w.dist) - 4.5f
    val gx = 4.9f; val gy = 4.8f; val kh = 4.4f
    val dwell = (s.dwellMs * 0.6f).toLong().coerceAtLeast(350L)
    fun typeKey(c: String) { b.type(if (b.shift) c.uppercase(tr) else c); b.shift = false }
    fun letter(c: Char) = KeyDef("kb:$c", if (b.shift) c.toString().uppercase(tr) else c.toString()) { typeKey(c.toString()) }
    val rows = mutableListOf<List<KeyDef>>()
    rows += "1234567890".map { letter(it) }
    rows += "qwertyuıopğü".map { letter(it) }
    rows += "asdfghjklşi".map { letter(it) }
    rows += listOf(KeyDef("kb:shift", "⇧", active = b.shift) { b.shift = !b.shift }) + "zxcvbnmöç.".map { letter(it) } +
        KeyDef("kb:back", "⌫") { b.type("backspace") }
    rows += "/:-_?=&@#%".map { letter(it) }
    rows += listOf(
        KeyDef("kb:com", ".com", 7f) { b.type(".com") },
        KeyDef("kb:space", "Boşluk", 22f) { b.type(" ") },
        KeyDef("kb:enter", "Git ⏎", 10f) { b.type("enter") },
        KeyDef("kb:close", "Kapat", 9f) { b.hideKeyboard() })
    rows.forEachIndexed { r, keys ->
        val total = keys.sumOf { (it.width + (gx - 4.6f)).toDouble() }.toFloat()
        var x = -total / 2f
        keys.forEach { k ->
            val cw = k.width + (gx - 4.6f)
            out += Target(k.id, w.yaw + x + cw / 2f, top - r * gy, 2f, k.width, kh, k.label, k.active, dwell = dwell, action = k.act)
            x += cw
        }
    }
    return out
}

/** Where inside [t] (0..1, from its top left) a hit landed, given its offset from the target's centre in the window's own degrees. */
private fun localUv(t: Target, dxDeg: Float, dyDeg: Float): Pair<Float, Float> {
    val r = Math.toRadians(t.rot.toDouble()); val c = cos(r).toFloat(); val sn = sin(r).toFloat()
    val x = dxDeg * c + dyDeg * sn
    val y = -dxDeg * sn + dyDeg * c
    return (0.5f + x / t.w).coerceIn(0f, 1f) to (0.5f - y / t.h).coerceIn(0f, 1f)
}

/** The offset of a gaze / cursor direction from [t]'s centre, in the window's own degrees (right, up). */
private fun offsetFrom(t: Target, yaw: Float, pitch: Float): Pair<Float, Float> {
    val sc = 2f / t.dist
    return angDiff(yaw, t.yaw) / sc to (pitch - t.pitch) / sc
}

/** One click on [t]: a page or bar gets where inside it was hit; every other target just runs. */
private fun fire(t: Target, dxDeg: Float, dyDeg: Float) {
    val page = t.touch; val bar = t.tapAt
    if (page == null && bar == null) { t.action(); return }
    val (u, v) = localUv(t, dxDeg, dyDeg)
    if (page != null) page(BrowserEngine.TAP, u, v) else bar?.invoke(u, v)
}

private fun hitAt(t: Target, yaw: Float, pitch: Float): Boolean {
    val s = 2f / t.dist
    return abs(angDiff(t.yaw, yaw)) <= t.w * s / 2f && abs(t.pitch - pitch) <= t.h * s / 2f
}

@Composable
fun VrScreen(store: SettingsStore, head: Head, hands: HandTracker, browser: BrowserEngine,
             onHandConfig: (Boolean, Boolean, String) -> Unit, recenter: () -> Unit, exit: () -> Unit) {
    val ctx = LocalContext.current
    val s by store.flow.collectAsState(initial = Settings())
    val d = remember { DesktopState() }
    val scope = rememberCoroutineScope()
    val webs = remember { WebAppsState { list -> scope.launch { store.setWebApps(WebApps.serialize(list)) } } }
    val home = remember { HomeState(webs) }
    val storeSt = remember { StoreState(webs) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    var hover by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf("NEXTvr") }
    val starField = remember { val r = Random(7); List(300) { Triple(r.nextFloat() * 360f - 180f, r.nextFloat() * 170f - 85f, r.nextFloat()) } }

    val cal = remember { HandCalibration() }
    cal.onDone = { v -> scope.launch { store.setPinchOn(v) } }
    val act = remember {
        Act(recenter, exit,
            { scope.launch { store.setPerformance(next(listOf("lite", "balanced", "precision"), s.performance)) } },
            { scope.launch { store.setDwell(next(listOf(500, 1000, 1500), s.dwellMs)) } },
            { scope.launch { store.setVrMode(next(listOf("standard", "desktop"), s.vrMode)) } },
            { scope.launch { store.setHand(!s.handTracking) } },
            { scope.launch { store.setCamera(if (s.camera == "front") "back" else "front") } },
            { head.yaw }, { head.pitch },
            { cal.start() }, { scope.launch { store.setPinchOn(0.28f) } }, { d.open("handcal", head.yaw, head.pitch) }, browser,
            home, storeSt,
            { url -> webs.icons.remove(url); scope.launch(kotlinx.coroutines.Dispatchers.IO) { WebApps.deleteIcon(ctx, url) } }) { e ->
            home.markOpened(e.id)
            when (e.kind) {
                "own" -> { d.open(e.key, head.yaw, head.pitch); home.close() }
                "env" -> { d.env = e.key.toInt(); home.close() }
                "local" -> { d.open("browser", head.yaw, head.pitch); home.close(); browser.openUrl(e.key, true) }
                "web" -> {
                    d.open("browser", head.yaw, head.pitch); home.close()
                    browser.openUrl(e.key, WebApps.needsDesktop(e.key))
                    // The site's own icon, fetched once after the first opening.
                    if (webs.icons[e.key] == null) scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                        WebApps.fetchSiteIcon(ctx, e.key)?.let { b -> webs.icons[e.key] = b.asImageBitmap() }
                    }
                }
                else -> {
                    home.close()
                    val intent = ctx.packageManager.getLaunchIntentForPackage(e.key)?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (intent == null) status = "${e.label} açılamadı (başlatılabilir değil)"
                    else runCatching { ctx.startActivity(intent) }.onFailure { status = "${e.label} açılamadı" }
                }
            }
        }
    }
    val targets by remember { derivedStateOf { buildTargets(d, s, act) } }

    val hasBrowser = d.windows.any { it.kind == "browser" }
    LaunchedEffect(hasBrowser) { if (hasBrowser) browser.start() else browser.stop() }
    LaunchedEffect(Unit) {
        val saved = store.flow.first().desktop
        if (!d.restore(saved)) home.open(0f)
    }
    LaunchedEffect(Unit) {
        home.android = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { runCatching { loadAndroidApps(ctx) }.getOrDefault(emptyList()) }
    }
    LaunchedEffect(Unit) { while (true) { home.refreshStatus(ctx); delay(5_000) } }
    // Saved web apps -> state; their saved icons are read from disk.
    LaunchedEffect(s.webApps) {
        val list = WebApps.parse(s.webApps)
        webs.sync(list)
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            list.forEach { a -> if (webs.icons[a.url] == null) WebApps.cachedIcon(ctx, a.url)?.let { webs.icons[a.url] = it.asImageBitmap() } }
        }
    }
    // Icons of the store page being shown (only those the phone already has).
    val storeOpen = d.windows.any { it.kind == "store" && !it.minimized }
    LaunchedEffect(storeOpen, storeSt.filter, storeSt.page, webs.installed) {
        if (!storeOpen) return@LaunchedEffect
        val shownNow = storeSt.shown()
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            shownNow.forEach { e -> if (webs.icons[e.url] == null) WebApps.cachedIcon(ctx, e.url)?.let { webs.icons[e.url] = it.asImageBitmap() } }
        }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { d.serialize() }.drop(1).collectLatest { delay(800); store.setDesktop(it) }
    }
    LaunchedEffect(Unit) {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            status = "NEXTvr  •  ${fmt.format(Date())}  •  %${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}"
            delay(30_000)
        }
    }
    LaunchedEffect(s.pinchOn) { hands.setPinch(s.pinchOn) }
    LaunchedEffect(s.handTracking, s.camera, s.performance) {
        onHandConfig(s.handTracking, s.camera == "front", s.performance)
    }
    // Gaze + hand + move-mode loop
    LaunchedEffect(Unit) {
        var cur: String? = null; var since = 0L; var fired = false
        var lastYaw = head.yaw; var lastPitch = head.pitch
        var stillSince = 0L; var prevMoving: Int? = null; var moveStart = 0L
        var prevBoth = false; var twoId: Int? = null; var tw0: Win? = null
        var dist0 = 1f; var ang0 = 0f; var midY0 = 0f; var midP0 = 0f
        var prevGrab = false; var dragId: Int? = null; var pageT: Target? = null; var offY = 0f; var offP = 0f; var lastPalm = hands.snap.palmCount
        while (true) {
            withFrameNanos { n ->
                val ms = n / 1_000_000L
                if (d.windows.any { it.kind == "handcal" && !it.minimized })
                    cal.update(hands.snap, hands.luma, s.handTracking && hands.status.startsWith("Aktif"), SystemClock.uptimeMillis())
                val mv = d.moving
                if (mv != prevMoving) { prevMoving = mv; moveStart = ms; stillSince = 0L }
                if (mv != null) {
                    d.update(mv) { it.copy(yaw = head.yaw, pitch = head.pitch) }
                    val sp = abs(angDiff(head.yaw, lastYaw)) + abs(head.pitch - lastPitch)
                    if (sp < 0.12f) {
                        if (stillSince == 0L) stillSince = ms
                        if (ms - stillSince > 1200 && ms - moveStart > 1500) d.moving = null
                    } else stillSince = 0L
                    hover = null; progress = 0f; cur = null
                } else if (hands.snap.let { it.visible && SystemClock.uptimeMillis() - it.ts < 300 }) {
                    // HAND MODE: head-locked cursor (index/pinch point) hits the same targets as gaze
                    val hs = hands.snap
                    val cy = head.yaw + (hs.px - 0.5f) * 70f
                    val cp = head.pitch - (hs.py - 0.5f) * 50f
                    val t = targets.asReversed().firstOrNull { hitAt(it, cy, cp) }
                    hover = t?.id; progress = 0f; cur = null
                    val grab = hs.pinch || hs.fist
                    val both = hs.visible2 && hs.pinch && hs.pinch2
                    if (both) {
                        // TWO-HAND: distance between pinch points = scale, angle between them = rotation, midpoint = move
                        hover = null
                        pageT?.let { it.touch?.invoke(MotionEvent.ACTION_CANCEL, .5f, .5f) }; pageT = null
                        val c2y = head.yaw + (hs.px2 - 0.5f) * 70f
                        val c2p = head.pitch - (hs.py2 - 0.5f) * 50f
                        val ddx = angDiff(c2y, cy); val ddy = c2p - cp
                        val dist = hypot(ddx, ddy).coerceAtLeast(1f)
                        val ang = Math.toDegrees(atan2(ddy.toDouble(), ddx.toDouble())).toFloat()
                        val midY = cy + ddx / 2f; val midP = (cp + c2p) / 2f
                        if (!prevBoth) {
                            val hitW = targets.asReversed().firstOrNull { it.label == null && (hitAt(it, cy, cp) || hitAt(it, c2y, c2p)) }
                                ?.id?.removePrefix("w:")?.toIntOrNull()
                            val win = d.windows.firstOrNull { it.id == (dragId ?: hitW) }
                                ?: d.windows.lastOrNull { !it.minimized && !it.pinned }
                            if (win != null && !win.pinned) {
                                twoId = win.id; d.focus(win.id); tw0 = win
                                dist0 = dist; ang0 = ang; midY0 = midY; midP0 = midP
                            } else twoId = null
                        }
                        val tid = twoId; val base = tw0
                        if (tid != null && base != null) {
                            val nw = (base.w * dist / dist0).coerceIn(18f, 90f)
                            var rot = angDiff(base.rot + angDiff(ang, ang0), 0f)
                            if (abs(rot) < 4f) rot = 0f      // snap upright
                            d.update(tid) { it.copy(w = nw, h = base.h * nw / base.w, rot = rot, maximized = false, prev = null,
                                yaw = base.yaw + angDiff(midY, midY0), pitch = base.pitch + (midP - midP0)) }
                        }
                        prevBoth = true; dragId = null; prevGrab = true
                    } else {
                    prevBoth = false
                    if (grab && !prevGrab) {
                        if (hs.pinch) {
                            if (t != null && (t.touch != null || t.tapAt != null)) {
                                val (dx, dy) = offsetFrom(t, cy, cp)
                                val page = t.touch
                                if (page != null) {
                                    pageT = t
                                    val (u, v) = localUv(t, dx, dy)
                                    page(MotionEvent.ACTION_DOWN, u, v)
                                } else fire(t, dx, dy)
                            } else if (t?.label != null) t.action()
                            else if (t != null) {
                                val wid = t.id.removePrefix("w:").toIntOrNull()
                                val win = d.windows.firstOrNull { it.id == wid }
                                if (wid != null && win != null) { d.focus(wid); if (!win.pinned) { dragId = wid; offY = win.yaw - cy; offP = win.pitch - cp } }
                            }
                        } else {
                            val top = d.windows.lastOrNull { !it.minimized && !it.pinned }
                            if (top != null) { dragId = top.id; offY = top.yaw - cy; offP = top.pitch - cp }
                        }
                    }
                    val pt = pageT
                    if (pt != null) {
                        val (dx, dy) = offsetFrom(pt, cy, cp)
                        val (u, v) = localUv(pt, dx, dy)
                        if (grab) pt.touch?.invoke(MotionEvent.ACTION_MOVE, u, v)
                        else { pt.touch?.invoke(MotionEvent.ACTION_UP, u, v); pageT = null }
                    }
                    val dg = dragId
                    if (grab && dg != null) d.update(dg) { it.copy(yaw = cy + offY, pitch = cp + offP) }
                    if (!grab) dragId = null
                    prevGrab = grab
                    }
                    if (hs.palmCount != lastPalm) { lastPalm = hs.palmCount; home.toggle(head.yaw) }
                } else {
                    dragId = null; prevGrab = false; prevBoth = false
                    pageT?.let { it.touch?.invoke(MotionEvent.ACTION_CANCEL, .5f, .5f) }; pageT = null
                    val t = targets.asReversed().firstOrNull { hitAt(it, head.yaw, head.pitch) }
                    val id = t?.id
                    if (id != cur) { cur = id; since = ms; fired = false; hover = id; progress = 0f }
                    else if (t != null && !fired) {
                        val need = t.dwell ?: if (t.label == null) 2000L else 1000L
                        val pr = ((ms - since).toFloat() / need).coerceIn(0f, 1f)
                        progress = if (t.label == null && t.touch == null && t.tapAt == null) 0f else pr
                        if (pr >= 1f) {
                            fired = true; progress = 0f
                            val (dx, dy) = offsetFrom(t, head.yaw, head.pitch)
                            fire(t, dx, dy)
                        }
                    }
                }
                lastYaw = head.yaw; lastPitch = head.pitch
            }
        }
    }

    val mono = s.vrMode == "desktop"
    val stars = when (s.performance) { "lite" -> 60; "precision" -> 300; else -> 140 }
    Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { size = it }
        .pointerInput(Unit) {
            detectTapGestures { off ->
                if (size.width == 0) return@detectTapGestures
                if (d.moving != null) { d.moving = null; return@detectTapGestures }
                val vw = if (mono) size.width.toFloat() else size.width / 2f
                val eye = if (mono) 0 else if (off.x < vw) -1 else 1
                val lx = off.x - (if (eye == 1) vw else 0f)
                val p = Proj(vw, size.height.toFloat(), mono)
                val t = targets.asReversed().firstOrNull { t ->
                    val sc = 2f / t.dist
                    abs(lx - p.x(t.yaw, head.yaw, t.dist, eye)) <= t.w * sc * p.ppd / 2f &&
                        abs(off.y - p.y(t.pitch, head.pitch)) <= t.h * sc * p.ppd / 2f
                }
                if (t != null) {
                    val sc = 2f / t.dist
                    val dx = (lx - p.x(t.yaw, head.yaw, t.dist, eye)) / (p.ppd * sc)
                    val dy = -(off.y - p.y(t.pitch, head.pitch)) / (p.ppd * sc)
                    fire(t, dx, dy)
                }
            }
        }) {
        if (size.width > 0) {
            val vw = if (mono) size.width.toFloat() else size.width / 2f
            val p = remember(size, mono) { Proj(vw, size.height.toFloat(), mono) }
            Row(Modifier.fillMaxSize()) {
                val eyes = if (mono) listOf(0) else listOf(-1, 1)
                eyes.forEach { e ->
                    EyeBox(e, p, head, d, s, stars, starField, targets, hover, { progress }, status, hands, cal, browser, home, storeSt, Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
    }
}

@Composable
private fun EyeBox(eye: Int, p: Proj, head: Head, d: DesktopState, s: Settings, stars: Int,
                   field: List<Triple<Float, Float, Float>>, targets: List<Target>, hover: String?,
                   progress: () -> Float, status: String, hands: HandTracker, cal: HandCalibration, browser: BrowserEngine, home: HomeState, store: StoreState, modifier: Modifier) {
    Box(modifier.clipToBounds().background(Color.Black)) {
        Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = -head.roll }) {
            Canvas(Modifier.fillMaxSize()) { drawEnv(d.env, p, head, eye, stars, field) }
            val vis = d.windows.filter { !it.minimized }
            val focusId = vis.lastOrNull()?.id
            vis.forEach { w -> key(w.id) { WindowView(w, w.id == focusId, p, head, eye, s, cal, browser, store, hover) } }
            targets.filter { !it.label.isNullOrEmpty() }.forEach { t ->
                key(t.id) {
                    Placed(head, p, eye, t.yaw, t.pitch, t.dist, t.w, t.h) { u ->
                        val hv = hover == t.id
                        val shape = RoundedCornerShape(30)
                        Box(Modifier.fillMaxSize()
                            .background(if (hv) Accent.copy(alpha = .45f) else if (t.active) Accent.copy(alpha = .22f) else Color(0xEB1B2433), shape)
                            .border(1.dp, Accent.copy(alpha = .4f), shape), contentAlignment = Alignment.Center) {
                            Text(t.label!!, color = Color.White, fontSize = px2sp(u * 2f), maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
            HomeLayer(home, d, head, p, eye, hover, browser.keyboardUp && vis.any { it.kind == "browser" })
            Placed(head, p, eye, 0f, 37f, 2f, 40f, 5f) { u ->
                Text(status, color = Color(0xFFB6C2D4), fontSize = px2sp(u * 2f), modifier = Modifier.align(Alignment.Center))
            }
        }
        Canvas(Modifier.fillMaxSize()) {
            val hs = hands.snap
            if (hs.visible && SystemClock.uptimeMillis() - hs.ts < 300) {
                val cx = size.width / 2f; val cy = size.height / 2f
                fun pos(q: com.nextvr.app.hand.Pt) = Offset(cx + (q.x - 0.5f) * 70f * p.ppd, cy + (q.y - 0.5f) * 50f * p.ppd)
                val bones = listOf(0 to 1, 1 to 2, 2 to 3, 3 to 4, 0 to 5, 5 to 6, 6 to 7, 7 to 8, 5 to 9, 9 to 10, 10 to 11, 11 to 12,
                    9 to 13, 13 to 14, 14 to 15, 15 to 16, 13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17)
                hs.hands.forEach { h ->
                    if (h.size == 21) {
                        bones.forEach { (a, b) -> drawLine(Color(0x8822D3EE), pos(h[a]), pos(h[b]), 2.dp.toPx()) }
                        h.forEach { drawCircle(Color.White.copy(alpha = .8f), 2.5.dp.toPx(), pos(it)) }
                    }
                }
                val c = pos(com.nextvr.app.hand.Pt(hs.px, hs.py))
                drawCircle(if (hs.pinch || hs.fist) Accent else Color.White, 9.dp.toPx(), c, style = if (hs.pinch || hs.fist) androidx.compose.ui.graphics.drawscope.Fill else Stroke(2.dp.toPx()))
            }
        }
        Text("El: ${hands.status}", color = Color(0xFF8FA0B8), fontSize = px2sp(p.ppd * 1.6f),
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 10.dp, bottom = 6.dp))
        if (d.moving != null) Text("Pencere taşınıyor — dokun veya 1 sn sabit bak", color = Accent,
            fontSize = px2sp(p.ppd * 2f), modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp))
        if (!head.available) Text("Baş takibi sensörü yok — dokunmatik kullan", color = Warn,
            fontSize = px2sp(p.ppd * 2f), modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp))
        // Head-gaze reticle is rendered in each eye, so it remains binocular in VR mode.
        // Hand tracking owns the pointer whenever it is enabled; never show the gaze dot then.
        if (!s.handTracking) Canvas(Modifier.fillMaxSize()) {
            val c = center
            drawCircle(Color.White, 4.dp.toPx(), c)
            val pr = progress()
            if (pr > 0f) {
                val r = 12.dp.toPx()
                drawArc(Accent, -90f, 360f * pr, false, c - Offset(r, r), Size(2 * r, 2 * r), style = Stroke(3.dp.toPx()))
            }
        }
    }
}

@Composable
private fun WindowView(w: Win, focused: Boolean, p: Proj, head: Head, eye: Int, s: Settings, cal: HandCalibration, browser: BrowserEngine, store: StoreState, hover: String?) {
    Placed(head, p, eye, w.yaw, w.pitch, w.dist, w.w, w.h, rot = w.rot) { u ->
        val shape = RoundedCornerShape(6)
        if (w.kind == "browser") {
            BrowserSurface(browser, focused, u)
            return@Placed
        }
        Box(Modifier.fillMaxSize().background(Panel.copy(alpha = .94f), shape)
            .border(if (focused) 2.dp else 1.dp, if (focused) Accent else Color(0x33FFFFFF), shape)) {
            Text(KIND_TITLE[w.kind] ?: w.kind, color = Color.White, fontSize = px2sp(u * 2.3f),
                modifier = Modifier.padding(start = (u * 2f).pxDp(), top = (u * 1.1f).pxDp()))
            if (w.kind == "store") StoreBody(w, store, u, hover) else {
                val body = when (w.kind) {
                    "settings" -> "Profil, gaze süresi ve mod aşağıdan değişir."
                    "apps" -> "Açmak için bir uygulamaya bak veya dokun."
                    "handcal" -> cal.text
                    else -> STAGE_NOTE[w.kind] ?: ""
                }
                Text(body, color = Color(0xFFB6C2D4), fontSize = px2sp(u * 1.8f),
                    modifier = Modifier.padding(start = (u * 2f).pxDp(), top = (u * 5.2f).pxDp()))
            }
        }
    }
}

/** The browser window: the bar on top, the live page under it. Both eyes draw the same two bitmaps. */
@Composable
private fun BoxScope.BrowserSurface(b: BrowserEngine, focused: Boolean, u: Float) {
    val shape = RoundedCornerShape(3)
    Box(Modifier.fillMaxSize().clip(shape).background(Color.White)
        .border(if (focused) 2.dp else 1.dp, if (focused) Accent else Color(0x33FFFFFF), shape)) {
        Canvas(Modifier.fillMaxSize()) {
            b.frameTick                                    // read here: every new page picture redraws the window
            val wPx = size.width.roundToInt()
            val barH = (size.width * BrowserChrome.BAR_H / BrowserChrome.BAR_W).roundToInt()
            b.bar?.let { drawImage(it, dstSize = IntSize(wPx, barH), filterQuality = FilterQuality.Medium) }
            val page = b.front
            if (page != null && !page.isRecycled) {
                drawImage(page.asImageBitmap(), srcSize = IntSize(BrowserEngine.W, BrowserEngine.H),
                    dstOffset = IntOffset(0, barH), dstSize = IntSize(wPx, size.height.roundToInt() - barH),
                    filterQuality = FilterQuality.Medium)
            }
        }
        val note = b.error ?: if (b.front == null) "Tarayıcı açılıyor…" else null
        if (note != null) Text(note, color = Color(0xFF5F6368), fontSize = px2sp(u * 2f), modifier = Modifier.align(Alignment.Center))
    }
}

private fun DrawScope.drawEnv(env: Int, p: Proj, head: Head, eye: Int, starCount: Int, field: List<Triple<Float, Float, Float>>) {
    val hy = head.yaw; val hp = head.pitch
    when (env) {
        1 -> {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF02030A), Color(0xFF0B1030))))
            for (i in 0 until minOf(starCount, field.size)) {
                val (sy, sp, sz) = field[i]
                val x = p.x(sy, hy, 1e6f, eye); val y = p.y(sp, hp)
                if (x in 0f..size.width && y in 0f..size.height)
                    drawCircle(Color.White.copy(alpha = .5f + sz * .5f), sz * 2.2f + .8f, Offset(x, y))
            }
        }
        2 -> {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF0B0F2A), Color(0xFF4A2160))))
            val horizon = p.y(-6f, hp)
            val rnd = Random(3)
            for (k in 0 until 72) {
                val hgt = 4f + rnd.nextFloat() * 14f
                val x0 = p.x(-180f + k * 5f, hy, 1e6f, eye)
                val wd = 5f * p.ppd + 1f
                if (x0 > size.width || x0 + wd < 0f) continue
                drawRect(Color(0xFF080812), Offset(x0, horizon - hgt * p.ppd), Size(wd, hgt * p.ppd + size.height))
            }
        }
        3 -> {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF1F2937), Color(0xFF0F172A))))
            val hz = p.y(-15f, hp)
            drawRect(Color(0xFF0B1220), Offset(0f, hz), Size(size.width, size.height))
            for (pt in listOf(-20f, -26f, -34f, -46f, -62f)) {
                val y = p.y(pt, hp); drawLine(Color(0x3322D3EE), Offset(0f, y), Offset(size.width, y), 2f)
            }
            for (k in -11..12) {
                val x = p.x(k * 15f, hy, 1e6f, eye); drawLine(Color(0x3322D3EE), Offset(x, hz), Offset(x, size.height), 2f)
            }
        }
        else -> drawRect(Brush.verticalGradient(listOf(Bg, Color(0xFF0B1220))))
    }
}
