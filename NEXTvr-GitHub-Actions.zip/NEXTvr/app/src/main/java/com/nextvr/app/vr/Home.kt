package com.nextvr.app.vr

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import kotlin.math.max

/*
 * The VR home as in NEXTvr-BE (Horizon style): a dock bar (status, pinned apps, recent apps, library
 * button) and, opened from it, the Library: round section icons at the left, the app tiles straight
 * on the room in staggered rows of 4, 5 and 4, page dots at the right edge.
 * Geometry is kept in the BE's panel pixels and mapped to degrees, so every drawn thing and its
 * hit target use the same numbers.
 */

/** One tile of the home. kind: "own" (a NEXTvr window), "android" (an installed app) or "env" (a world). */
class HomeEntry(
    val id: String, val label: String, val kind: String, val key: String,
    val glyph: ImageVector? = null, val tint: String? = null, val icon: ImageBitmap? = null,
)

enum class HomeTab(val title: String, val icon: ImageVector) {
    ALL("Tümü", Icons.Rounded.Apps), OWN("Uygulamalar", Icons.Rounded.GridView),
    ANDROID("Android", Icons.Rounded.Android), WEB("Web", Icons.Rounded.Public), ENV("Dünyalar", Icons.Rounded.Landscape)
}

object HomeGeo {
    /** Library panel (BE: 1800x1350 px) mapped to 70 degrees wide. */
    const val PANEL_W = 1800f
    const val PANEL_H = 1350f
    const val DEG = 70f / PANEL_W
    const val LIB_PITCH = 2f
    const val ICON = 136f
    const val CELL_W = 262f
    const val GRID_X = 900f
    const val GRID_TOP = 400f
    const val ROW_PITCH = 255f
    const val PER_PAGE = 13
    private val ROW_SIZES = intArrayOf(4, 5, 4)
    private val ROW_START = intArrayOf(0, 4, 9)
    const val RAIL_X = 110f
    const val RAIL_TOP = 340f
    const val RAIL_PITCH = 96f
    const val RAIL_D = 80f
    const val DOTS_X = 1690f
    const val DOTS_Y = 640f

    fun cell(index: Int): Pair<Float, Float> {
        val i = index % PER_PAGE
        val row = if (i < ROW_START[1]) 0 else if (i < ROW_START[2]) 1 else 2
        return Pair(GRID_X + ((i - ROW_START[row]) - (ROW_SIZES[row] - 1) / 2f) * CELL_W, GRID_TOP + row * ROW_PITCH)
    }
    fun railY(index: Int) = RAIL_TOP + index * RAIL_PITCH + RAIL_D / 2
    fun sortY() = RAIL_TOP + HomeTab.entries.size * RAIL_PITCH + 40f + RAIL_D / 2
    fun dotY(i: Int, pages: Int) = DOTS_Y + (i - (pages - 1) / 2f) * 44f
}

/** The dock bar, in degrees (distance 2 m). */
object DockGeo {
    const val PITCH = -30f
    const val H = 6.6f
    const val PAD = 1.6f
    const val SLOT = 5.6f
    const val ICON = 4.6f
    const val STATUS_W = 10.5f
    const val DIV_W = 1.2f
    const val PINNED = 4
    const val RECENT = 3
}

class DockItem(val id: String, val kind: Int, val entry: HomeEntry?, val w: Float, val x: Float) {
    companion object { const val STATUS = 0; const val DIV = 1; const val APP = 2; const val LIB = 3 }
}

class HomeState(private val webs: WebAppsState) {
    var libraryOpen by mutableStateOf(false); private set
    var yaw by mutableFloatStateOf(0f); private set
    var tab by mutableStateOf(HomeTab.ALL); private set
    var page by mutableIntStateOf(0); private set
    var byName by mutableStateOf(false); private set
    /** Installed apps; null while they are still being read. */
    var android by mutableStateOf<List<HomeEntry>?>(null)
    /** Ids opened in this session, newest first. */
    val opened = mutableStateListOf<String>()
    var clock by mutableStateOf("")
    var battery by mutableIntStateOf(100)
    var charging by mutableStateOf(false)
    var wifi by mutableStateOf(false)

    fun open(atYaw: Float) { yaw = atYaw; libraryOpen = true; page = 0 }
    fun close() { libraryOpen = false }
    fun toggle(atYaw: Float) { if (libraryOpen) close() else open(atYaw) }
    fun setTab(t: HomeTab) { tab = t; page = 0 }
    fun toggleSort() { byName = !byName; page = 0 }
    fun showPage(i: Int) { page = i.coerceIn(0, pages() - 1) }
    fun markOpened(id: String) { opened.remove(id); opened.add(0, id) }

    fun list(): List<HomeEntry> {
        val apps = android.orEmpty()
        val base = when (tab) {
            HomeTab.ALL -> OWN + BUNDLED + webs.entries() + apps
            HomeTab.OWN -> OWN + BUNDLED
            HomeTab.ANDROID -> apps
            HomeTab.WEB -> webs.entries()
            HomeTab.ENV -> ENVIRONMENTS
        }
        if (tab == HomeTab.ENV) return base
        return if (byName) base.sortedBy { it.label.lowercase() }
        else base.sortedBy { e -> opened.indexOf(e.id).let { if (it < 0) Int.MAX_VALUE else it } }
    }
    fun pages() = max(1, (list().size + HomeGeo.PER_PAGE - 1) / HomeGeo.PER_PAGE)
    fun shown(): List<HomeEntry> = list().drop(page.coerceIn(0, pages() - 1) * HomeGeo.PER_PAGE).take(HomeGeo.PER_PAGE)

    fun pinned(): List<HomeEntry> = OWN.take(DockGeo.PINNED)
    /** Apps opened lately first, then the next installed apps. */
    fun recent(): List<HomeEntry> {
        val apps = android.orEmpty()
        val byId = apps.associateBy { it.id }
        val lately = opened.mapNotNull { byId[it] }
        return (lately + apps).distinctBy { it.id }.take(DockGeo.RECENT)
    }

    fun refreshStatus(c: Context) {
        clock = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        runCatching {
            val sticky = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = sticky?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = sticky?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = sticky?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            battery = if (level < 0) 100 else level * 100 / scale.coerceAtLeast(1)
            charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        }
        wifi = runCatching {
            val m = c.getSystemService(ConnectivityManager::class.java)
            m.getNetworkCapabilities(m.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }.getOrDefault(false)
    }

    companion object {
        private val GLYPH = mapOf("browser" to Icons.Rounded.Public, "video" to Icons.Rounded.Movie,
            "store" to Icons.Rounded.Store, "settings" to Icons.Rounded.Settings)
        val OWN: List<HomeEntry> = APPS.map { HomeEntry("own:${it.kind}", it.name, "own", it.kind, GLYPH[it.kind] ?: Icons.Rounded.Apps, "own:${it.kind}") }
        /** Pages that ship inside the app (assets) and open in the browser window, no network needed. */
        const val WIN7_URL = "file:///android_asset/win7/win7.html"
        val BUNDLED: List<HomeEntry> = listOf(HomeEntry("local:win7", "Windows 7", "local", WIN7_URL, Icons.Rounded.Computer, "own:win7"))
        val ENVIRONMENTS: List<HomeEntry> = ENVS.mapIndexed { i, n -> HomeEntry("env:$i", n, "env", i.toString(), Icons.Rounded.Landscape, "env:$i") }
    }

    /** Dock items left to right, each with its centre offset (degrees) from the dock's middle. */
    fun dockItems(): List<DockItem> {
        val raw = ArrayList<Triple<String, Int, HomeEntry?>>()
        raw += Triple("status", DockItem.STATUS, null)
        raw += Triple("d0", DockItem.DIV, null)
        pinned().forEach { raw += Triple(it.id, DockItem.APP, it) }
        val rec = recent()
        if (rec.isNotEmpty()) {
            raw += Triple("d1", DockItem.DIV, null)
            rec.forEach { raw += Triple(it.id, DockItem.APP, it) }
        }
        raw += Triple("d2", DockItem.DIV, null)
        raw += Triple("library", DockItem.LIB, null)
        fun w(k: Int) = when (k) { DockItem.STATUS -> DockGeo.STATUS_W; DockItem.DIV -> DockGeo.DIV_W; else -> DockGeo.SLOT }
        val total = raw.sumOf { w(it.second).toDouble() }.toFloat()
        var x = -total / 2f
        return raw.map { (id, k, e) -> DockItem(id, k, e, w(k), x + w(k) / 2f).also { x += w(k) } }
    }
    fun dockWidth() = dockItems().sumOf { it.w.toDouble() }.toFloat() + 2 * DockGeo.PAD
}

/** Installed apps with a launcher icon (needs the <queries> entry of the manifest). Call off the main thread. */
fun loadAndroidApps(ctx: Context): List<HomeEntry> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { ri ->
            val pkg = ri.activityInfo.packageName
            HomeEntry("android:$pkg", ri.loadLabel(pm).toString(), "android", pkg, icon = bitmapOf(runCatching { ri.loadIcon(pm) }.getOrNull()))
        }
        .sortedBy { it.label.lowercase() }
}

private fun bitmapOf(d: Drawable?): ImageBitmap? = runCatching {
    d ?: return null
    val b = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, 128, 128); d.draw(android.graphics.Canvas(b))
    b.asImageBitmap()
}.getOrNull()

// ------------------------------------------------------------------------------------ targets

fun dockTargets(h: HomeState, a: Act, d: DesktopState): List<Target> {
    val open = d.windows.map { it.kind }.toSet()
    return h.dockItems().mapNotNull { it ->
        when (it.kind) {
            DockItem.DIV -> null
            DockItem.STATUS -> Target("dock:status", it.x, DockGeo.PITCH, 2f, it.w, DockGeo.H, "") { a.launch(HomeState.OWN.first { e -> e.key == "settings" }) }
            DockItem.LIB -> Target("dock:library", it.x, DockGeo.PITCH, 2f, it.w, DockGeo.H, "", a.home.libraryOpen) { a.home.toggle(a.hy()) }
            else -> { val e = it.entry!!
                Target("dock:${e.id}", it.x, DockGeo.PITCH, 2f, it.w, DockGeo.H, "", e.kind == "own" && e.key in open) { a.launch(e) } }
        }
    }
}

fun libraryTargets(h: HomeState, a: Act): List<Target> {
    val g = HomeGeo
    fun yaw(x: Float) = h.yaw + (x - g.GRID_X) * g.DEG
    fun pit(y: Float) = g.LIB_PITCH - (y - g.PANEL_H / 2f) * g.DEG
    val out = ArrayList<Target>()
    HomeTab.entries.forEachIndexed { i, t ->
        out += Target("lib:tab:${t.name}", yaw(g.RAIL_X), pit(g.railY(i)), 2f, g.RAIL_D * g.DEG, g.RAIL_D * g.DEG, "", t == h.tab) { h.setTab(t) }
    }
    if (h.tab != HomeTab.ENV) out += Target("lib:sort", yaw(g.RAIL_X), pit(g.sortY()), 2f, g.RAIL_D * g.DEG, g.RAIL_D * g.DEG, "") { h.toggleSort() }
    val pages = h.pages()
    if (pages > 1) for (i in 0 until pages) {
        out += Target("lib:page:$i", yaw(g.DOTS_X), pit(g.dotY(i, pages)), 2f, 60f * g.DEG, 48f * g.DEG, "", i == h.page) { h.showPage(i) }
    }
    h.shown().forEachIndexed { i, e ->
        val (x, y) = g.cell(i)
        out += Target("lib:app:${e.id}", yaw(x), pit(y + 33f), 2f, g.CELL_W * g.DEG, (g.ICON + 114f) * g.DEG, "") { a.launch(e) }
    }
    return out
}

// ------------------------------------------------------------------------------------ drawing

private val GLASS_TOP = Color(0xEB2B2F36)
private val GLASS_BOTTOM = Color(0xEB1D2026)
private val INK = Color(0xFFF2F2F2)
private val INK_SOFT = INK.copy(alpha = .7f)
private val FAINT = INK.copy(alpha = .1f)
private val EDGE = Color(0x33FFFFFF)
private val ONLINE = Color(0xFF0B8A1B)

private fun Modifier.glass(shape: Shape, elevation: Dp) = this
    .shadow(elevation, shape, ambientColor = Color(0x40000000), spotColor = Color(0x40000000))
    .clip(shape)
    .background(Brush.verticalGradient(listOf(GLASS_TOP, GLASS_BOTTOM)))
    .border(Dp.Hairline, EDGE, shape)

private fun Modifier.tileGloss(shape: Shape) = this
    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .20f), Color.Transparent, Color.Black.copy(alpha = .10f))))
    .border(Dp.Hairline, Color.White.copy(alpha = .28f), shape)

/** A box of [w]x[h] units whose centre is at ([cx], [cy]); [k] screen px per unit. */
@Composable
private fun At(k: Float, cx: Float, cy: Float, w: Float, h: Float, align: Alignment = Alignment.Center, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.offset(((cx - w / 2) * k).pxDp(), ((cy - h / 2) * k).pxDp()).size((w * k).pxDp(), (h * k).pxDp()),
        contentAlignment = align, content = content)
}

@Composable
internal fun HText(text: String, color: Color, sizePx: Float, modifier: Modifier = Modifier, weight: FontWeight = FontWeight.Normal,
                  align: TextAlign = TextAlign.Start, lines: Int = 1, shadow: Boolean = false) {
    val sp = px2sp(sizePx)
    BasicText(text, modifier, maxLines = lines, overflow = TextOverflow.Ellipsis,
        style = TextStyle(color = color, fontSize = sp, fontWeight = weight, textAlign = align, lineHeight = sp * 1.2f,
            shadow = if (shadow) Shadow(Color(0xAA000000), Offset(0f, 2f), 10f) else null))
}

@Composable
private fun Glyph(icon: ImageVector, color: Color, sizePx: Float) = Icon(icon, null, tint = color, modifier = Modifier.size(sizePx.pxDp()))

/** An app tile: gradient + white glyph for NEXTvr's own apps and worlds, the app's own icon for installed apps. */
@Composable
internal fun Tile(e: HomeEntry, sz: Float) {
    val shape = RoundedCornerShape(30)
    val key = e.tint ?: e.id
    val glyph = e.glyph
    val context = LocalContext.current
    val bundledWebIcon = remember(e.kind, e.key) { if (e.kind == "web") StoreIconAssets.load(context, e.key)?.asImageBitmap() else null }
    val shownIcon = e.icon ?: bundledWebIcon
    val gradient = AppIcons.GRADIENTS[key]
    val palette = remember(key) { AppIcons.palette(key) }
    val box = Modifier.size(sz.pxDp()).clip(shape)
    if (glyph != null && gradient != null) {
        Box(box.background(Brush.linearGradient(listOf(Color(gradient.first), Color(gradient.second)))).tileGloss(shape), Alignment.Center) { Glyph(glyph, Color.White, sz * .5f) }
    } else if (glyph != null) {
        Box(box.background(Color(palette.tile)).tileGloss(shape), Alignment.Center) { Glyph(glyph, Color(palette.glyph), sz * .5f) }
    } else if (shownIcon != null) {
        Image(shownIcon, null, contentScale = ContentScale.Crop, modifier = box)
    } else {
        Box(box.background(Color(palette.tile)).tileGloss(shape), Alignment.Center) {
            HText(e.label.take(1).uppercase(), Color(palette.glyph), sz * .42f, weight = FontWeight.SemiBold)
        }
    }
}

/** Dock and (when open) library, drawn into one eye. */
@Composable
fun HomeLayer(home: HomeState, d: DesktopState, head: Head, p: Proj, eye: Int, hover: String?, keyboardUp: Boolean) {
    if (!keyboardUp) Dock(home, d, head, p, eye, hover)
    if (home.libraryOpen) Library(home, head, p, eye, hover)
}

@Composable
private fun Dock(home: HomeState, d: DesktopState, head: Head, p: Proj, eye: Int, hover: String?) {
    val items = home.dockItems()
    val dw = home.dockWidth()
    val open = d.windows.map { it.kind }.toSet()
    Placed(head, p, eye, 0f, DockGeo.PITCH, 2f, dw, DockGeo.H) { u ->
        val h = DockGeo.H
        Box(Modifier.fillMaxSize().glass(RoundedCornerShape(50), (1.2f * u).pxDp()))
        for (it in items) {
            val cx = dw / 2f + it.x
            when (it.kind) {
                DockItem.DIV -> At(u, cx, h / 2f, .1f, h * .58f) { Box(Modifier.fillMaxSize().background(FAINT)) }
                DockItem.STATUS -> {
                    val on = hover == "dock:status"
                    At(u, cx, h / 2f, it.w, DockGeo.ICON) {
                        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(50)).background(if (on) FAINT else Color.Transparent), Alignment.Center) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                HText(home.clock, INK_SOFT, 1.8f * u)
                                Spacer(Modifier.width((.5f * u).pxDp()))
                                Glyph(if (home.wifi) Icons.Rounded.Wifi else Icons.Rounded.WifiOff, INK, 1.9f * u)
                                Spacer(Modifier.width((.5f * u).pxDp()))
                                Battery(home.battery, home.charging, 2.0f * u, 1.2f * u)
                            }
                        }
                    }
                }
                DockItem.APP -> {
                    val e = it.entry!!
                    val on = hover == "dock:${e.id}"
                    val sz = DockGeo.ICON * (if (on) 1.1f else 1f) * u
                    At(u, cx, h / 2f, DockGeo.SLOT, DockGeo.ICON * 1.15f) {
                        Box(Modifier.shadow((.4f * u).pxDp(), RoundedCornerShape(27))) { Tile(e, sz) }
                    }
                    if (e.kind == "own" && e.key in open) At(u, cx, h - .5f, .45f, .45f) { Box(Modifier.fillMaxSize().clip(CircleShape).background(INK)) }
                }
                DockItem.LIB -> {
                    val sel = home.libraryOpen
                    val on = hover == "dock:library"
                    At(u, cx, h / 2f, DockGeo.ICON, DockGeo.ICON) {
                        Box(Modifier.fillMaxSize().clip(CircleShape).background(if (sel) INK else if (on) FAINT else Color.Transparent), Alignment.Center) {
                            Glyph(Icons.Rounded.Interests, if (sel) Color(0xFF272727) else INK, 2.6f * u)
                        }
                    }
                }
            }
        }
    }
}

/** The battery as in the Horizon bar: an outline with the charge filled in. */
@Composable
private fun Battery(level: Int, charging: Boolean, wPx: Float, hPx: Float) {
    val low = level in 0..15 && !charging
    Canvas(Modifier.size(wPx.pxDp(), hPx.pxDp())) {
        val stroke = size.height * .12f
        val body = size.width * .88f
        drawRoundRect(INK, Offset(stroke / 2, stroke / 2), Size(body - stroke, size.height - stroke), CornerRadius(size.height * .22f), style = Stroke(stroke))
        drawRoundRect(INK, Offset(body + stroke * .3f, size.height * .32f), Size(size.width - body - stroke * .3f, size.height * .36f), CornerRadius(stroke))
        val inner = stroke * 2
        drawRoundRect(if (low) Color(0xFFE53935) else if (charging) ONLINE else INK, Offset(inner, inner),
            Size((body - inner * 2) * level.coerceIn(0, 100) / 100f, size.height - inner * 2), CornerRadius(stroke * .6f))
    }
}

@Composable
private fun Library(home: HomeState, head: Head, p: Proj, eye: Int, hover: String?) {
    val g = HomeGeo
    val shown = home.shown()
    val pages = home.pages()
    val pinnedIds = remember { home.pinned().map { it.id }.toSet() }
    Placed(head, p, eye, home.yaw, g.LIB_PITCH, 2f, g.PANEL_W * g.DEG, g.PANEL_H * g.DEG) { u ->
        val k = u * g.DEG
        // The section icons, then sorting.
        @Composable
        fun RailIcon(cy: Float, icon: ImageVector, chosen: Boolean, on: Boolean, hint: String) {
            At(k, g.RAIL_X, cy, g.RAIL_D, g.RAIL_D) {
                Box(Modifier.fillMaxSize().clip(CircleShape)
                    .background(if (chosen) Color.White.copy(alpha = .94f) else if (on) Color.White.copy(alpha = .32f) else Color.Black.copy(alpha = .22f)),
                    Alignment.Center) { Glyph(icon, if (chosen) Color(0xFF272727) else Color.White, 40f * k) }
            }
            if (on) At(k, g.RAIL_X + g.RAIL_D / 2 + 20f + 280f, cy, 560f, 60f, Alignment.CenterStart) { HText(hint, Color.White, 30f * k, weight = FontWeight.Medium, shadow = true) }
        }
        HomeTab.entries.forEachIndexed { i, t -> RailIcon(g.railY(i), t.icon, t == home.tab, hover == "lib:tab:${t.name}", t.title) }
        if (home.tab != HomeTab.ENV) RailIcon(g.sortY(), Icons.Rounded.SwapVert, false, hover == "lib:sort", if (home.byName) "Sırala: Ada göre" else "Sırala: Son kullanılanlar")

        if (shown.isEmpty()) {
            val msg = if (home.tab == HomeTab.WEB) "Mağazadan web uygulamaları ekleyin"
            else if (home.tab == HomeTab.ANDROID || home.tab == HomeTab.ALL) {
                if (home.android == null) "Uygulamalar yükleniyor…" else "Yüklü Android uygulaması bulunamadı"
            } else ""
            if (msg.isNotEmpty()) At(k, g.GRID_X, 560f, 1000f, 80f) { HText(msg, Color(0xDDFFFFFF), 38f * k, align = TextAlign.Center, shadow = true) }
        }
        shown.forEachIndexed { i, e ->
            val (x, y) = g.cell(i)
            val on = hover == "lib:app:${e.id}"
            val sz = g.ICON * (if (on) 1.08f else 1f) * k
            val shape = RoundedCornerShape(30)
            At(k, x, y, g.ICON + 28f, g.ICON + 28f) {
                Box(Modifier.size(sz.pxDp())
                    .shadow(((if (on) 26f else 14f) * k).pxDp(), shape, ambientColor = Color(0x66000000), spotColor = Color(0x66000000))
                    .clip(shape)
                    .then(if (on) Modifier.border((4f * k).pxDp(), Color.White, shape) else Modifier)) { Tile(e, sz) }
            }
            val labelTop = y + g.ICON / 2 + 18f
            At(k, x, labelTop + 38f, g.CELL_W - 12f, 76f, Alignment.TopCenter) {
                if (e.id in pinnedIds) Row(verticalAlignment = Alignment.CenterVertically) {
                    Glyph(Icons.Rounded.PushPin, Color.White, 22f * k)
                    Spacer(Modifier.width((6f * k).pxDp()))
                    HText(e.label, Color.White, 29f * k, Modifier.widthIn(max = ((g.CELL_W - 56f) * k).pxDp()), FontWeight.Medium, shadow = true)
                } else HText(e.label, Color.White, 29f * k, Modifier.width(((g.CELL_W - 16f) * k).pxDp()), FontWeight.Medium, TextAlign.Center, 2, true)
            }
        }
        if (pages > 1) for (i in 0 until pages) {
            val cur = i == home.page
            At(k, g.DOTS_X, g.dotY(i, pages), 16f, if (cur) 36f else 16f) {
                Box(Modifier.fillMaxSize().clip(CircleShape).background(if (cur) Color.White else if (hover == "lib:page:$i") Color(0xCCFFFFFF) else Color(0x80FFFFFF)))
            }
        }
    }
}
