package com.nextvr.app.vr
import androidx.compose.runtime.*
import com.nextvr.app.browser.BrowserChrome
import com.nextvr.app.browser.BrowserEngine

data class Win(val id: Int, val kind: String, val yaw: Float, val pitch: Float, val dist: Float = 2f,
               val w: Float = 40f, val h: Float = 28f, val minimized: Boolean = false,
               val maximized: Boolean = false, val pinned: Boolean = false, val prev: List<Float>? = null,
               val rot: Float = 0f)

data class App(val kind: String, val name: String)
val APPS = listOf(App("browser", "Tarayıcı"), App("video", "Video"), App("store", "Mağaza"), App("settings", "Ayarlar"))
val ENVS = listOf("Karanlık", "Uzay", "Gece şehir", "Minimal")
val LAYOUTS = listOf("Serbest", "Yan yana", "Geniş", "Odak")
val KIND_TITLE: Map<String, String> = mapOf("apps" to "Uygulamalar", "handcal" to "El Kalibrasyonu") + APPS.associate { it.kind to it.name }
val STAGE_NOTE = mapOf(
    "video" to "Medya merkezi Aşama 9'da eklenecek.")

/** The browser window is the bar (tabs + toolbar) over a 1600x1000 page: its height follows its width. */
val BROWSER_ASPECT = BrowserChrome.BAR_H.toFloat() / BrowserChrome.BAR_W + BrowserEngine.H.toFloat() / BrowserEngine.W

/** The browser keeps its shape whatever size a layout gives it; every other window takes the size as given. */
fun Win.fit(): Win = if (kind == "browser") copy(h = w * BROWSER_ASPECT) else this

class DesktopState {
    val windows = mutableStateListOf<Win>()      // list order = z-order, last = top
    var env by mutableIntStateOf(0)
    var layout by mutableIntStateOf(0)
    var moving by mutableStateOf<Int?>(null)
    private var nextId = 1

    private fun idx(id: Int) = windows.indexOfFirst { it.id == id }
    fun update(id: Int, f: (Win) -> Win) { val i = idx(id); if (i >= 0) windows[i] = f(windows[i]) }

    fun open(kind: String, hy: Float, hp: Float) {
        val i = windows.indexOfFirst { it.kind == kind }
        if (i >= 0) { val w = windows.removeAt(i).copy(minimized = false); windows.add(w) }
        else windows.add(Win(nextId++, kind, hy + ((windows.size % 3) - 1) * 4f, hp,
            w = when (kind) { "settings" -> 52f; "handcal" -> 46f; "browser" -> 48f; "store" -> 64f; else -> 40f },
            h = when (kind) { "settings", "handcal" -> 32f; "browser" -> 48f * BROWSER_ASPECT; "store" -> 44f; else -> 28f }))
    }
    fun focus(id: Int) { val i = idx(id); if (i >= 0 && i != windows.lastIndex) windows.add(windows.removeAt(i)) }
    fun close(id: Int) { windows.removeAll { it.id == id }; if (moving == id) moving = null }
    fun minimize(id: Int) = update(id) { it.copy(minimized = true) }
    fun togglePin(id: Int) = update(id) { it.copy(pinned = !it.pinned) }
    fun toggleMax(id: Int, hy: Float, hp: Float) = update(id) { x ->
        val pv = x.prev
        if (x.maximized && pv != null) x.copy(maximized = false, yaw = pv[0], pitch = pv[1], w = pv[2], h = pv[3], prev = null)
        else x.copy(maximized = true, prev = listOf(x.yaw, x.pitch, x.w, x.h), yaw = hy, pitch = hp, w = 70f, h = 46f).fit()
    }

    fun applyLayout(mode: Int, hy: Float) {
        val ids = windows.filter { !it.minimized && !it.pinned }.map { it.id }
        val n = ids.size
        if (n == 0) return
        when (mode) {
            1 -> ids.forEachIndexed { k, id -> update(id) { it.copy(yaw = hy + (k - (n - 1) / 2f) * 38f, pitch = 0f, w = 36f, h = 26f, maximized = false, prev = null, rot = 0f).fit() } }
            2 -> {
                update(ids.last()) { it.copy(yaw = hy, pitch = 0f, w = 56f, h = 38f, maximized = false, prev = null, rot = 0f).fit() }
                ids.dropLast(1).forEachIndexed { j, id ->
                    update(id) { it.copy(yaw = hy + (if (j % 2 == 0) -1 else 1) * 40f, pitch = 6f - (j / 2) * 20f, w = 26f, h = 18f, maximized = false, prev = null, rot = 0f).fit() }
                }
            }
            3 -> {
                update(ids.last()) { it.copy(yaw = hy, pitch = 0f, w = 55f, h = 36f, maximized = false, prev = null, rot = 0f).fit() }
                ids.dropLast(1).forEach { minimize(it) }
            }
        }
    }

    fun serialize(): String = "$env,$layout#" + windows.joinToString(";") {
        "${it.id},${it.kind},${it.yaw},${it.pitch},${it.dist},${it.w},${it.h},${if (it.minimized) 1 else 0},${if (it.pinned) 1 else 0},${it.rot}"
    }

    fun restore(s: String): Boolean {
        return try {
            val parts = s.split("#", limit = 2)
            val hdr = parts[0].split(",")
            val list = parts[1].split(";").filter { it.isNotBlank() }.map {
                val f = it.split(",")
                Win(f[0].toInt(), f[1], f[2].toFloat(), f[3].toFloat(), f[4].toFloat(), f[5].toFloat(), f[6].toFloat(), f[7] == "1", false, f[8] == "1", null, if (f.size > 9) f[9].toFloat() else 0f)
            }
            if (list.isEmpty()) return false
            windows.clear(); windows.addAll(list)
            nextId = (list.maxOf { it.id }) + 1
            env = hdr[0].toInt().coerceIn(0, ENVS.size - 1)
            layout = hdr[1].toInt().coerceIn(0, LAYOUTS.size - 1)
            true
        } catch (e: Exception) { false }
    }
}
