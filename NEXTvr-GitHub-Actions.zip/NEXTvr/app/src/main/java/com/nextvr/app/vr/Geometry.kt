package com.nextvr.app.vr
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.*

/** Head orientation in degrees, relative to the last recenter. */
class Head {
    var yaw by mutableFloatStateOf(0f)
    var pitch by mutableFloatStateOf(0f)
    var roll by mutableFloatStateOf(0f)
    var available by mutableStateOf(true)
}

fun angDiff(a: Float, b: Float): Float {
    var d = (a - b) % 360f
    if (d > 180f) d -= 360f
    if (d < -180f) d += 360f
    return d
}

/** Projection for ONE eye viewport (w x h px). Everything in the world is placed by angles (deg) + distance (m). */
class Proj(val w: Float, val h: Float, val mono: Boolean) {
    val ppd = h / 80f                         // ~80 deg vertical field of view
    val ipdPx = if (mono) 0f else w * 0.035f  // parallax strength
    // Objects at 2 m have zero disparity (screen plane); nearer = more, farther = less.
    fun x(yaw: Float, headYaw: Float, dist: Float, eye: Int) =
        w / 2f + angDiff(yaw, headYaw) * ppd - eye * ipdPx * (1f / dist - 0.5f)
    fun y(pitch: Float, headPitch: Float) = h / 2f - (pitch - headPitch) * ppd
}

@Composable fun Float.pxDp(): Dp = with(LocalDensity.current) { this@pxDp.toDp() }
@Composable fun px2sp(px: Float): TextUnit = with(LocalDensity.current) { px.toSp() }

/** Places [content] in the world. Size is given in degrees at 2 m; [content] receives px-per-degree for this item. */
@Composable
fun Placed(head: Head, p: Proj, eye: Int, yaw: Float, pitch: Float, dist: Float, wDeg: Float, hDeg: Float, rot: Float = 0f,
           content: @Composable BoxScope.(Float) -> Unit) {
    val s = 2f / dist
    val wPx = wDeg * s * p.ppd
    val hPx = hDeg * s * p.ppd
    Box(Modifier.size(wPx.pxDp(), hPx.pxDp()).graphicsLayer {
        translationX = p.x(yaw, head.yaw, dist, eye) - wPx / 2f
        translationY = p.y(pitch, head.pitch) - hPx / 2f
        rotationZ = -rot   // rot is counter-clockwise degrees
    }) { content(p.ppd * s) }
}
