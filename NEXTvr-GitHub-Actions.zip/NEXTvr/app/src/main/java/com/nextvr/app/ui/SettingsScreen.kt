package com.nextvr.app.ui
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import com.nextvr.app.data.*
import com.nextvr.app.ui.theme.*

@Composable
fun SettingsScreen(store: SettingsStore, back: () -> Unit) {
    val s by store.flow.collectAsState(initial = Settings())
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = back) { Text("← Geri") }
        Text("Ayarlar", style = MaterialTheme.typography.headlineMedium)
        Choice("VR modu", listOf("standard", "desktop"), s.vrMode) { scope.launch { store.setVrMode(it) } }
        Choice("Performans profili", listOf("lite", "balanced", "precision"), s.performance) { scope.launch { store.setPerformance(it) } }
        Text("Gaze bekleme: ${s.dwellMs} ms")
        Slider(value = s.dwellMs.toFloat(), onValueChange = { scope.launch { store.setDwell(it.toInt()) } }, valueRange = 500f..1500f)
    }
}

@Composable
private fun Choice(title: String, opts: List<String>, cur: String, pick: (String) -> Unit) {
    Text(title, style = MaterialTheme.typography.titleSmall)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEach { FilterChip(selected = it == cur, onClick = { pick(it) }, label = { Text(it) }) }
    }
}
