package com.nextvr.app.hand
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.core.ErrorListener
import com.google.mediapipe.tasks.core.OutputHandler.ResultListener
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * CameraX (RGBA, KEEP_ONLY_LATEST) -> MediaPipe HandLandmarker (LIVE_STREAM) -> GestureEngine.
 * Everything runs on-device; no frame leaves the phone. Model: app/src/main/assets/hand_landmarker.task
 */
class HandTracker(private val ctx: Context) {
    companion object { const val MODEL = "hand_landmarker.task" }

    var snap by mutableStateOf(HandSnapshot()); private set
    var status by mutableStateOf("Kapalı"); private set
    var luma by mutableFloatStateOf(-1f); private set
    private var lumaN = 0

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val gestures = GestureEngine()
    @Volatile private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    @Volatile private var generation = 0
    @Volatile private var front = true
    @Volatile private var aspect = 0.75f
    @Volatile private var interval = 1
    @Volatile private var lastFrameTimestamp = 0L
    private var profile = "balanced"
    private var lastReq: Pair<Boolean, String>? = null
    private var running = false
    private var delegateName = "CPU"
    private var frameNo = 0L
    private var bmp: Bitmap? = null

    fun setPinch(v: Float) { gestures.pinchOn = v; gestures.pinchOff = v + 0.12f }

    private fun sampleLuma(b: Bitmap): Float {
        var sum = 0f; var n = 0
        val sx = (b.width / 12).coerceAtLeast(1); val sy = (b.height / 12).coerceAtLeast(1)
        for (i in 0 until 12) for (j in 0 until 12) {
            val c = b.getPixel((i * sx + sx / 2).coerceAtMost(b.width - 1), (j * sy + sy / 2).coerceAtMost(b.height - 1))
            sum += 0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255); n++
        }
        return sum / n
    }

    private fun modelPresent() = ctx.assets.list("")?.contains(MODEL) == true

    fun start(owner: LifecycleOwner, useFront: Boolean, prof: String) {
        val req = useFront to prof
        if (running && req == lastReq) return
        stop()
        lastReq = req; running = true; front = useFront; profile = prof
        gestures.configure(prof)
        // Process every available frame. CameraX KEEP_ONLY_LATEST drops stale frames for us.
        // Skipping frames here made pointer/gesture response feel unnecessarily delayed.
        interval = 1
        if (!modelPresent()) { running = false; status = "Model yok: assets/hand_landmarker.task"; return }
        status = "Başlatılıyor…"
        val gen = ++generation
        exec.execute {
            val lm = try { build(prof) } catch (e: Throwable) { main.post { status = "Model yüklenemedi: ${e.message}"; running = false }; return@execute }
            main.post {
                if (gen != generation) { try { lm.close() } catch (_: Throwable) {}; return@post }
                landmarker = lm
                bind(owner, useFront, prof, gen)
            }
        }
    }

    fun stop() {
        generation++
        running = false; lastReq = null
        try { provider?.unbindAll() } catch (_: Throwable) {}
        val lm = landmarker; landmarker = null
        try { lm?.close() } catch (_: Throwable) {}
        busy.set(false)
        snap = HandSnapshot()
        status = "Kapalı"
    }

    private fun build(prof: String): HandLandmarker {
        fun opts(del: Delegate) = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL).setDelegate(del).build())
            .setRunningMode(RunningMode.LIVE_STREAM).setNumHands(2)
            // Slightly more permissive thresholds help reacquire hands quickly in ordinary indoor light.
            // Tracking remains enabled by LIVE_STREAM, avoiding full palm detection on every frame.
            .setMinHandDetectionConfidence(0.45f).setMinHandPresenceConfidence(0.45f).setMinTrackingConfidence(0.45f)
            .setResultListener(ResultListener<HandLandmarkerResult, MPImage> { r, img -> onResult(r, img) })
            .setErrorListener(ErrorListener { e -> busy.set(false); main.post { status = "Hata: ${e.message}" } })
            .build()
        // Prefer GPU for the responsive/balanced and precision profiles. Some Android
        // devices/drivers do not support the MediaPipe GPU delegate, so always fall back.
        if (prof != "lite") {
            try {
                val l = HandLandmarker.createFromOptions(ctx, opts(Delegate.GPU))
                delegateName = "GPU"
                return l
            } catch (_: Throwable) {
                // Safe CPU fallback for unsupported or unstable GPU drivers.
            }
        }
        delegateName = "CPU"
        return HandLandmarker.createFromOptions(ctx, opts(Delegate.CPU))
    }

    private fun bind(owner: LifecycleOwner, useFront: Boolean, prof: String, gen: Int) {
        val fut = ProcessCameraProvider.getInstance(ctx)
        fut.addListener({
            if (gen != generation) return@addListener
            try {
                val prov = fut.get(); provider = prov
                val res = when (prof) { "lite" -> Size(320, 240); "precision" -> Size(640, 480); else -> Size(480, 360) }
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(ResolutionSelector.Builder()
                        .setResolutionStrategy(ResolutionStrategy(res, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)).build())
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
                analysis.setAnalyzer(exec, analyzer)
                prov.unbindAll()
                prov.bindToLifecycle(owner, if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA, analysis)
                status = "Aktif ($delegateName, $prof)"
            } catch (e: Exception) { status = "Kamera hatası: ${e.message}"; running = false }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private val analyzer = ImageAnalysis.Analyzer { img ->
        try {
            frameNo++
            val lm = landmarker
            // Analyze every fresh frame; KEEP_ONLY_LATEST prevents a backlog.
            if (lm == null || frameNo % interval != 0L || !busy.compareAndSet(false, true)) return@Analyzer
            val rot = img.imageInfo.rotationDegrees
            aspect = if (rot % 180 == 0) img.width.toFloat() / img.height else img.height.toFloat() / img.width
            val b = toBitmap(img)
            if (lumaN++ % 6 == 0) {
                val measuredLuma = sampleLuma(b)
                main.post { luma = measuredLuma }
            }
            val now = SystemClock.uptimeMillis()
            val timestamp = if (now > lastFrameTimestamp) now else lastFrameTimestamp + 1L
            lastFrameTimestamp = timestamp
            lm.detectAsync(BitmapImageBuilder(b).build(),
                ImageProcessingOptions.builder().setRotationDegrees(rot).build(), timestamp)
        } catch (e: Throwable) {
            busy.set(false)
        } finally { img.close() }
    }

    private fun toBitmap(img: ImageProxy): Bitmap {
        val plane = img.planes[0]; val w = img.width; val h = img.height
        if (plane.rowStride != w * 4) return img.toBitmap()   // padded rows: safe (allocating) path
        var b = bmp
        if (b == null || b.width != w || b.height != h) { b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); bmp = b }
        plane.buffer.rewind(); b!!.copyPixelsFromBuffer(plane.buffer)
        return b
    }

    private fun onResult(r: HandLandmarkerResult, img: MPImage) {
        val mirror = front   // mirror applied ONCE, here, for selfie view
        val hands = r.landmarks().mapIndexed { i, lms ->
            val mp = r.handedness().getOrNull(i)?.firstOrNull()
            // MediaPipe assumes a mirrored image; we feed unmirrored frames -> swap to get the real hand
            val label = when (mp?.categoryName()) { "Left" -> "Right"; "Right" -> "Left"; else -> "Right" }
            HandData(label, lms.map { Pt(if (mirror) 1f - it.x() else it.x(), it.y()) }, mp?.score() ?: 0f)
        }
        val next = gestures.update(hands, SystemClock.uptimeMillis(), aspect)
        busy.set(false)
        main.post {
            if (running) snap = next
        }
    }
}
