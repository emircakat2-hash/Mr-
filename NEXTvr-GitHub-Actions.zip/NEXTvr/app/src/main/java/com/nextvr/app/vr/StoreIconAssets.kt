package com.nextvr.app.vr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri

/** Bundled launcher artwork imported from the supplied NEXTvr-BE source project. */
object StoreIconAssets {
    private val packageByHost = mapOf(
        "youtube.com" to "app.revanced.android.youtube",
        "music.youtube.com" to "app.revanced.android.apps.youtube.music",
        "instagram.com" to "com.instagram.android",
        "threads.net" to "com.instagram.barcelona",
        "spotify.com" to "com.spotify.music",
        "open.spotify.com" to "com.spotify.music",
        "whatsapp.com" to "com.whatsapp",
        "web.whatsapp.com" to "com.whatsapp",
        "telegram.org" to "org.telegram.messenger",
        "t.me" to "org.telegram.messenger",
        "gmail.com" to "com.google.android.gm",
        "mail.google.com" to "com.google.android.gm",
        "maps.google.com" to "com.google.android.apps.maps",
        "google.com/maps" to "com.google.android.apps.maps",
        "translate.google.com" to "com.google.android.apps.translate",
        "keep.google.com" to "com.google.android.keep",
        "facebook.com" to "com.facebook.katana",
        "messenger.com" to "com.facebook.orca",
        "tiktok.com" to "com.ss.android.ugc.aweme",
        "pinterest.com" to "com.pinterest",
        "play.google.com" to "com.android.vending",
        "chrome.google.com" to "com.android.chrome",
        "photos.google.com" to "com.google.android.apps.photos",
        "google.com" to "com.google.android.googlequicksearchbox"
    )

    private val cache = HashMap<String, Bitmap?>()

    /** Finds a bundled icon by website host. Returns null when this source has no matching artwork. */
    @Synchronized
    fun load(context: Context, url: String): Bitmap? {
        val host = Uri.parse(url).host?.lowercase()?.removePrefix("www.") ?: return null
        val packageName = packageByHost.entries
            .sortedByDescending { it.key.length }.firstOrNull { (domain, _) -> host == domain || host.endsWith(".$domain") }
            ?.value ?: return null
        val key = packageName
        if (cache.containsKey(key)) return cache[key]
        val file = "$packageName.png"
        val bitmap = sequenceOf("icons/light/$file", "icons/dark/$file")
            .mapNotNull { path -> runCatching { context.assets.open(path).use { BitmapFactory.decodeStream(it) } }.getOrNull() }
            .firstOrNull()
        cache[key] = bitmap
        return bitmap
    }
}
