package com.nextvr.app.browser

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils

/**
 * The browser's bar on top of its VR window: a tab strip (tabs, ×, +) over a toolbar (back, forward,
 * reload, the address field with its star, an extension chip, a profile circle and ⋮).
 * Ported from the NEXTvr-BE browser; drawn once into a bitmap whenever something on it changes.
 */
object BrowserChrome {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Where the tab strip is in 0..1 of the bar's width, for [tabs] tabs: the tabs and the + after them. */
    fun tabsSpan(tabs: Int): Pair<Float, Float> =
        (TABS_L / BAR_W) to ((TABS_L + tabs * tabWidth(tabs) + 80f) / BAR_W)

    const val BAR_W = 1600
    const val BAR_H = 176

    /** What the address field says on a new tab, as in Chrome. */
    const val PLACEHOLDER = "Google üzerinde arayın veya bir URL yazın"

    /** Where the tab strip ends and the toolbar starts, px. */
    private const val ROW1 = 88f
    private const val TABS_L = 20f
    private const val OMNI_L = 260f
    private const val OMNI_R = 1300f

    /** What is at (u, v) of the browser bar, or null. */
    fun barAction(u: Float, v: Float, tabs: Int): String? {
        val x = u * BAR_W; val y = v * BAR_H
        return if (y < ROW1) {
            val width = tabWidth(tabs)
            val index = ((x - TABS_L) / width).toInt()
            when {
                x >= TABS_L && index in 0 until tabs -> if (x > TABS_L + (index + 1) * width - 60f) "closetab:$index" else "tab:$index"
                x >= TABS_L + tabs * width && x < TABS_L + tabs * width + 80f -> "newtab"
                else -> "move"
            }
        } else when {
            x < 100f -> "back"
            x < 170f -> "forward"
            x < 245f -> "reload"
            x > BAR_W - 90f -> "home"          // ⋮
            x > BAR_W - 170f -> "profile"      // the profile circle (looks only)
            x > OMNI_R -> "extensions"         // the extension chip (looks only)
            x > OMNI_R - 100f -> "bookmark"    // ☆ inside the address field
            else -> "address"
        }
    }

    private fun tabWidth(tabs: Int) = minOf(360f, (BAR_W - 40f - 100f) / tabs.coerceAtLeast(1))

    /** Chrome's colours, light or dark. */
    private class ChromeLook(dark: Boolean) {
        val strip = if (dark) Color.rgb(32, 33, 36) else Color.rgb(222, 225, 230)
        val page = if (dark) Color.rgb(53, 54, 58) else Color.WHITE
        val omni = if (dark) Color.rgb(32, 33, 36) else Color.rgb(241, 243, 244)
        val ink = if (dark) Color.rgb(232, 234, 237) else Color.rgb(32, 33, 36)
        val soft = if (dark) Color.rgb(154, 160, 166) else Color.rgb(95, 99, 104)
        val line = if (dark) Color.rgb(95, 99, 104) else Color.rgb(218, 220, 224)
        val blue = if (dark) Color.rgb(138, 180, 248) else Color.rgb(26, 115, 232)
    }

    private val barText = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        textAlign = Paint.Align.LEFT
    }

    private fun starPath(cx: Float, cy: Float, outer: Float, inner: Float) = Path().apply {
        for (i in 0 until 10) {
            val rad = if (i % 2 == 0) outer else inner
            val a = Math.toRadians(-90.0 + i * 36.0)
            val x = cx + (rad * Math.cos(a)).toFloat(); val y = cy + (rad * Math.sin(a)).toFloat()
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

    /** The four-colour Google "G". */
    private fun drawG(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.BUTT
        paint.strokeWidth = r * .42f
        val oval = RectF(cx - r, cy - r, cx + r, cy + r)
        paint.color = Color.rgb(234, 67, 53); canvas.drawArc(oval, 200f, 115f, false, paint)
        paint.color = Color.rgb(251, 188, 5); canvas.drawArc(oval, 135f, 66f, false, paint)
        paint.color = Color.rgb(52, 168, 83); canvas.drawArc(oval, 45f, 91f, false, paint)
        paint.color = Color.rgb(66, 133, 244); canvas.drawArc(oval, 0f, 46f, false, paint)
        canvas.drawLine(cx, cy, cx + r + paint.strokeWidth / 2, cy, paint)
        paint.style = Paint.Style.FILL
    }

    /** A small padlock, for pages that are not the new-tab page. */
    private fun drawLock(canvas: Canvas, cx: Float, cy: Float, color: Int) {
        paint.color = color
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3.5f
        paint.strokeCap = Paint.Cap.BUTT
        canvas.drawArc(RectF(cx - 7f, cy - 15f, cx + 7f, cy + 3f), 180f, 180f, false, paint)
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(RectF(cx - 11f, cy - 3f, cx + 11f, cy + 14f), 3f, 3f, paint)
    }

    /** The browser bar: tabs and +; back, forward, reload, the address field, the extension chip, profile and ⋮. */
    @Synchronized
    fun drawBar(address: String, tabs: List<String>, active: Int, dark: Boolean): Bitmap {
        val look = ChromeLook(dark)
        val bitmap = Bitmap.createBitmap(BAR_W, BAR_H, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val w = BAR_W.toFloat()
        val h = BAR_H.toFloat()
        val r = 56f
        paint.shader = null
        paint.style = Paint.Style.FILL
        // The strip (rounded at the top), then the toolbar over its lower part.
        paint.color = look.strip
        canvas.drawPath(Path().apply {
            addRoundRect(RectF(0f, 0f, w, h), floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f), Path.Direction.CW)
        }, paint)
        paint.color = look.page
        canvas.drawRect(0f, ROW1, w, h, paint)
        paint.color = look.line
        canvas.drawRect(0f, h - 2f, w, h, paint)
        paint.strokeCap = Paint.Cap.ROUND

        // ---- tab strip
        val width = tabWidth(tabs.size)
        val tabTop = 12f
        val tabMid = (tabTop + ROW1) / 2
        barText.textSize = 28f
        tabs.forEachIndexed { i, title ->
            val left = TABS_L + i * width
            val right = left + width - 6f
            if (i == active) {
                // White tab, rounded at the top and flared into the toolbar at the bottom, like Chrome's.
                val f = 14f; val c = 18f
                paint.style = Paint.Style.FILL
                paint.color = look.page
                canvas.drawPath(Path().apply {
                    moveTo(left - f, ROW1 + 1f)
                    quadTo(left, ROW1 + 1f, left, ROW1 - f)
                    lineTo(left, tabTop + c)
                    quadTo(left, tabTop, left + c, tabTop)
                    lineTo(right - c, tabTop)
                    quadTo(right, tabTop, right, tabTop + c)
                    lineTo(right, ROW1 - f)
                    quadTo(right, ROW1 + 1f, right + f, ROW1 + 1f)
                    close()
                }, paint)
            } else if (i + 1 != active && i + 1 < tabs.size) {
                // A thin divider between two background tabs.
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.color = look.soft
                paint.alpha = 90
                canvas.drawLine(right + 3f, tabMid - 14f, right + 3f, tabMid + 14f, paint)
                paint.alpha = 255
            }
            barText.color = if (i == active) look.ink else look.soft
            val shown = TextUtils.ellipsize(title, barText, width - 100f, TextUtils.TruncateAt.END).toString()
            canvas.drawText(shown, left + 24f, tabMid + 10f, barText)
            // × on each tab.
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = look.soft
            val cx = right - 30f
            canvas.drawLine(cx - 8f, tabMid - 8f, cx + 8f, tabMid + 8f, paint)
            canvas.drawLine(cx + 8f, tabMid - 8f, cx - 8f, tabMid + 8f, paint)
        }
        // + for a new tab.
        paint.style = Paint.Style.STROKE
        paint.color = look.soft
        paint.strokeWidth = 4f
        val px = TABS_L + tabs.size * width + 40f
        canvas.drawLine(px - 12f, tabMid, px + 12f, tabMid, paint)
        canvas.drawLine(px, tabMid - 12f, px, tabMid + 12f, paint)

        // ---- toolbar
        val cy = (ROW1 + h) / 2
        paint.strokeWidth = 4.5f
        paint.color = look.soft
        // ← back
        canvas.drawLine(40f, cy, 72f, cy, paint)
        canvas.drawLine(40f, cy, 54f, cy - 14f, paint)
        canvas.drawLine(40f, cy, 54f, cy + 14f, paint)
        // → forward
        canvas.drawLine(120f, cy, 152f, cy, paint)
        canvas.drawLine(152f, cy, 138f, cy - 14f, paint)
        canvas.drawLine(152f, cy, 138f, cy + 14f, paint)
        // ↻ reload: an open circle with an arrowhead where it ends.
        val rx = 207f; val rr = 15f
        canvas.drawArc(RectF(rx - rr, cy - rr, rx + rr, cy + rr), 20f, 300f, false, paint)
        run {
            val a = Math.toRadians(320.0)
            val ex = rx + (rr * Math.cos(a)).toFloat(); val ey = cy + (rr * Math.sin(a)).toFloat()
            val tx = (-Math.sin(a)).toFloat(); val ty = Math.cos(a).toFloat()   // direction of travel
            val nx = Math.cos(a).toFloat(); val ny = Math.sin(a).toFloat()      // outwards
            paint.style = Paint.Style.FILL
            canvas.drawPath(Path().apply {
                moveTo(ex + tx * 11f, ey + ty * 11f)
                lineTo(ex - tx * 3f + nx * 10f, ey - ty * 3f + ny * 10f)
                lineTo(ex - tx * 3f - nx * 10f, ey - ty * 3f - ny * 10f)
                close()
            }, paint)
        }

        // The address field.
        val field = RectF(OMNI_L, ROW1 + 11f, OMNI_R, h - 11f)
        paint.style = Paint.Style.FILL
        paint.color = look.omni
        canvas.drawRoundRect(field, field.height() / 2, field.height() / 2, paint)
        val starred = address.startsWith("★ ")
        val plain = address.removePrefix("★ ")
        val editing = plain.endsWith("|")
        val placeholder = plain == PLACEHOLDER
        if (placeholder || editing) drawG(canvas, field.left + 40f, cy, 14f) else drawLock(canvas, field.left + 40f, cy, look.soft)
        barText.textSize = 30f
        barText.color = if (placeholder) look.soft else look.ink
        val room = field.width() - 76f - 96f
        val shown = TextUtils.ellipsize(plain, barText, room, if (placeholder) TextUtils.TruncateAt.END else TextUtils.TruncateAt.START).toString()
        canvas.drawText(shown, field.left + 76f, cy + 10f, barText)
        // ☆ / ★ at the right end of the field.
        val sx = field.right - 50f
        if (starred) {
            paint.style = Paint.Style.FILL
            paint.color = look.blue
            canvas.drawPath(starPath(sx, cy, 17f, 7.5f), paint)
        } else {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3.5f
            paint.strokeJoin = Paint.Join.ROUND
            paint.color = look.soft
            canvas.drawPath(starPath(sx, cy, 17f, 7.5f), paint)
            paint.strokeJoin = Paint.Join.MITER
        }

        // The extension chip: a small yellow box with "···".
        val ex = (OMNI_R + w - 170f) / 2 - 20f
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(244, 200, 23)
        canvas.drawRoundRect(RectF(ex - 20f, cy - 14f, ex + 20f, cy + 14f), 5f, 5f, paint)
        paint.color = Color.rgb(60, 60, 60)
        for (i in -1..1) canvas.drawCircle(ex + i * 11f, cy, 2.8f, paint)
        // A divider, then the profile circle.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = look.line
        canvas.drawLine(w - 190f, cy - 16f, w - 190f, cy + 16f, paint)
        val ax = w - 130f
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(120, 144, 156)
        canvas.drawCircle(ax, cy, 20f, paint)
        canvas.save()
        canvas.clipPath(Path().apply { addCircle(ax, cy, 20f, Path.Direction.CW) })
        paint.color = Color.rgb(236, 239, 241)
        canvas.drawCircle(ax, cy - 5f, 7.5f, paint)
        canvas.drawOval(RectF(ax - 16f, cy + 6f, ax + 16f, cy + 32f), paint)
        canvas.restore()
        // ⋮ menu (it takes you to the new-tab page).
        paint.color = look.soft
        val dx = w - 45f
        for (i in -1..1) canvas.drawCircle(dx, cy + i * 12f, 3.6f, paint)
        paint.style = Paint.Style.FILL
        return bitmap
    }
}
