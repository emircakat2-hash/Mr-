package com.nextvr.app.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
val Bg = Color(0xFF070A12); val Panel = Color(0xFF111827); val Accent = Color(0xFF22D3EE)
val Ok = Color(0xFF22C55E); val Warn = Color(0xFFF59E0B); val Err = Color(0xFFEF4444)
@Composable fun NextVrTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel, onBackground = Color(0xFFE5E7EB), onSurface = Color(0xFFE5E7EB)),
    content = content)
