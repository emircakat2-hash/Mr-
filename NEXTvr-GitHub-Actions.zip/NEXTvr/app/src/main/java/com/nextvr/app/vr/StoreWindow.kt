package com.nextvr.app.vr

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.nextvr.app.data.Settings
import com.nextvr.app.store.AppStoreCatalog
import com.nextvr.app.store.WebApp
import com.nextvr.app.ui.theme.*
import kotlin.math.max
import kotlin.math.min

/** The web apps the user added (shown in the library's Web section) and their site icons. */
class WebAppsState(private val persist: (List<WebApp>) -> Unit) {
    var installed by mutableStateOf<List<WebApp>>(emptyList()); private set
    val icons: SnapshotStateMap<String, ImageBitmap> = mutableStateMapOf()

    /** The saved list came (back) from the settings. */
    fun sync(list: List<WebApp>) { installed = list }
    fun has(url: String) = installed.any { it.url == url }
    fun add(name: String, url: String) { if (!has(url)) update(installed + WebApp(name, url)) }
    fun remove(url: String) { update(installed.filterNot { it.url == url }) }
    private fun update(list: List<WebApp>) { installed = list; persist(list) }
    fun entries(): List<HomeEntry> = installed.map { HomeEntry("web:${it.url}", it.name, "web", it.url, icon = icons[it.url]) }
}

/** The store window: filter (Tümü, Yüklenenler, categories) and pages of 8 cards. */
class StoreState(val webs: WebAppsState) {
    var filter by mutableIntStateOf(0); private set
    var page by mutableIntStateOf(0); private set
    val filters: List<String> = listOf("Tümü", "Yüklenenler") + AppStoreCatalog.CATEGORIES

    fun mine() = filter == 1
    fun list(): List<AppStoreCatalog.Entry> = when (filter) {
        0 -> AppStoreCatalog.ALL
        1 -> AppStoreCatalog.ALL.filter { webs.has(it.url) }
        else -> AppStoreCatalog.ALL.filter { it.category == filters[filter] }
    }
    fun pages() = max(1, (list().size + StoreGeo.PER_PAGE - 1) / StoreGeo.PER_PAGE)
    fun shown(): List<AppStoreCatalog.Entry> = list().drop(page.coerceIn(0, pages() - 1) * StoreGeo.PER_PAGE).take(StoreGeo.PER_PAGE)
    fun filterTitle() = filters[filter] + if (filter == 1) " (${webs.installed.size})" else " (${list().size})"
    fun cycleFilter(d: Int) { filter = (filter + d + filters.size) % filters.size; page = 0 }
    fun turn(d: Int) { page = (page + d).coerceIn(0, pages() - 1) }
}

/** Window layout in a 64 x 44 degree design space (origin centre, y up); scaled with the window. */
object StoreGeo {
    const val DW = 64f
    const val DH = 44f
    const val PER_PAGE = 8
    const val FILTER_Y = 15.5f
    const val NAV_Y = -19f
    private val ROW_Y = floatArrayOf(8.6f, 2.0f, -4.6f, -11.2f)
    const val CARD_W = 29.4f
    const val CARD_H = 5.8f
    /** (centre x, centre y) of card [i]. */
    fun card(i: Int): Pair<Float, Float> = Pair(if (i % 2 == 0) -15f else 15f, ROW_Y[(i / 2).coerceIn(0, 3)])
}

/** Hit targets of a store window; every one is drawn by [StoreBody] (empty label = no chip). */
fun storeTargets(w: Win, st: StoreState, a: Act, s: Settings): List<Target> {
    val sx = w.w / StoreGeo.DW; val sy = w.h / StoreGeo.DH
    val dwell = s.dwellMs.toLong()
    val out = ArrayList<Target>()
    fun t(id: String, dx: Float, dy: Float, cw: Float, ch: Float, act: () -> Unit) {
        val (yy, pp) = windowPoint(w, dx * sx, dy * sy)
        out += Target("w:${w.id}:$id", yy, pp, w.dist, cw * sx, ch * sy, "", false, rot = w.rot, dwell = dwell, action = act)
    }
    t("sf-", -27.5f, StoreGeo.FILTER_Y, 4.4f, 4.6f) { st.cycleFilter(-1) }
    t("sf+", -1.5f, StoreGeo.FILTER_Y, 4.4f, 4.6f) { st.cycleFilter(1) }
    t("sp-", -10f, StoreGeo.NAV_Y, 11f, 4.4f) { st.turn(-1) }
    t("sp+", 10f, StoreGeo.NAV_Y, 11f, 4.4f) { st.turn(1) }
    st.shown().forEachIndexed { i, e ->
        val (cx, cy) = StoreGeo.card(i)
        t("card$i", cx, cy, StoreGeo.CARD_W, StoreGeo.CARD_H) {
            when {
                st.mine() -> { st.webs.remove(e.url); a.webRemoved(e.url) }
                st.webs.has(e.url) -> a.launch(HomeEntry("web:${e.url}", e.name, "web", e.url, icon = st.webs.icons[e.url]))
                else -> st.webs.add(e.name, e.url)
            }
        }
    }
    return out
}

/** A box at a pixel position (centre) and size. */
@Composable
private fun AtPx(cx: Float, cy: Float, w: Float, h: Float, align: Alignment = Alignment.Center, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.offset((cx - w / 2).pxDp(), (cy - h / 2).pxDp()).size(w.pxDp(), h.pxDp()), contentAlignment = align, content = content)
}

/** The inside of a store window, drawn into one eye; [u] is px per degree. */
@Composable
fun BoxScope.StoreBody(w: Win, st: StoreState, u: Float, hover: String?) {
    val sx = w.w / StoreGeo.DW; val sy = w.h / StoreGeo.DH; val f = min(sx, sy)
    fun px(dx: Float) = (w.w / 2f + dx * sx) * u
    fun py(dy: Float) = (w.h / 2f - dy * sy) * u
    val soft = Color(0xFFB6C2D4)
    val pages = st.pages()
    val shown = st.shown()
    val mine = st.mine()

    @Composable
    fun Round(id: String, dx: Float, dy: Float, cw: Float, ch: Float, label: String) {
        AtPx(px(dx), py(dy), cw * sx * u, ch * sy * u) {
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(50)).background(if (hover == "w:${w.id}:$id") Color(0x44FFFFFF) else Color(0x1FFFFFFF)),
                Alignment.Center) { HText(label, Color.White, 2.2f * f * u, weight = FontWeight.Bold) }
        }
    }
    Round("sf-", -27.5f, StoreGeo.FILTER_Y, 4.4f, 4.6f, "‹")
    AtPx(px(-14.5f), py(StoreGeo.FILTER_Y), 20f * sx * u, 4.6f * sy * u) {
        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(50)).background(Accent), Alignment.Center) {
            HText(st.filterTitle(), Color(0xFF04121A), 1.9f * f * u, weight = FontWeight.SemiBold, align = TextAlign.Center)
        }
    }
    Round("sf+", -1.5f, StoreGeo.FILTER_Y, 4.4f, 4.6f, "›")
    AtPx(px(17f), py(StoreGeo.FILTER_Y), 28f * sx * u, 4.6f * sy * u) {
        HText("“Al” ana ekrana ekler · “Aç” tarayıcıda açar", soft, 1.5f * f * u, align = TextAlign.Center)
    }

    shown.forEachIndexed { i, e ->
        val (cx, cy) = StoreGeo.card(i)
        val on = hover == "w:${w.id}:card$i"
        val has = st.webs.has(e.url)
        AtPx(px(cx), py(cy), StoreGeo.CARD_W * sx * u, StoreGeo.CARD_H * sy * u) {
            Row(Modifier.fillMaxSize().clip(RoundedCornerShape(18)).background(if (on) Color(0x33FFFFFF) else Color(0x14FFFFFF))
                .padding(horizontal = (.8f * f * u).pxDp()), verticalAlignment = Alignment.CenterVertically) {
                Tile(HomeEntry("web:${e.url}", e.name, "web", e.url, icon = st.webs.icons[e.url]), 4.4f * f * u)
                Spacer(Modifier.width((.9f * f * u).pxDp()))
                Column(Modifier.weight(1f)) {
                    HText(e.name, Color.White, 1.9f * f * u, weight = FontWeight.SemiBold)
                    HText(e.category, soft, 1.4f * f * u)
                }
                Box(Modifier.size((6.8f * f * u).pxDp(), (3.2f * f * u).pxDp()).clip(RoundedCornerShape(50))
                    .background(if (mine) Err else if (has) Color(0x33FFFFFF) else Accent), Alignment.Center) {
                    HText(if (mine) "Sil" else if (has) "Aç" else "Al", if (!mine && !has) Color(0xFF04121A) else Color.White,
                        1.6f * f * u, weight = FontWeight.Bold, align = TextAlign.Center)
                }
            }
        }
    }
    if (shown.isEmpty()) AtPx(px(0f), py(0f), 40f * sx * u, 6f * sy * u) {
        HText(if (mine) "Henüz web uygulaması eklemediniz" else "Bu bölümde uygulama yok", soft, 2f * f * u, align = TextAlign.Center)
    }

    Round("sp-", -10f, StoreGeo.NAV_Y, 11f, 4.4f, "‹ Önceki")
    AtPx(px(0f), py(StoreGeo.NAV_Y), 8f * sx * u, 4.4f * sy * u) {
        HText("${st.page.coerceIn(0, pages - 1) + 1} / $pages", soft, 1.8f * f * u, align = TextAlign.Center)
    }
    Round("sp+", 10f, StoreGeo.NAV_Y, 11f, 4.4f, "Sonraki ›")
}
