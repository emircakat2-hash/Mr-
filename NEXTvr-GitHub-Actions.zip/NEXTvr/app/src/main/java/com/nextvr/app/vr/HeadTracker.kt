package com.nextvr.app.vr
import android.content.Context
import android.hardware.*
import android.view.Surface
import kotlin.math.*

/** Rotation-vector based 3DoF head tracking. Forward = -Z of the device (looking through the screen). */
class HeadTracker(ctx: Context, private val head: Head, private val rotation: () -> Int) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val m = FloatArray(9)
    private var rawYaw = 0f
    private var yawOffset = 0f
    private var needCenter = true

    init { head.available = sensor != null }
    fun start() { sensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) } }
    fun stop() { sm.unregisterListener(this) }
    fun recenter() { yawOffset = rawYaw }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(m, e.values)
        val fx = -m[2]; val fy = -m[5]; val fz = -m[8]
        rawYaw = Math.toDegrees(atan2(fx.toDouble(), fy.toDouble())).toFloat()
        if (needCenter) { yawOffset = rawYaw; needCenter = false }
        head.yaw = angDiff(rawYaw, yawOffset)
        head.pitch = Math.toDegrees(asin(fz.coerceIn(-1f, 1f).toDouble())).toFloat()
        // roll: angle between the screen-up vector and the horizon-referenced up
        val (a, b) = when (rotation()) {
            Surface.ROTATION_90 -> 1f to 0f
            Surface.ROTATION_180 -> 0f to -1f
            Surface.ROTATION_270 -> -1f to 0f
            else -> 0f to 1f
        }
        val ux = a * m[0] + b * m[1]; val uy = a * m[3] + b * m[4]; val uz = a * m[6] + b * m[7]
        var rx = -fz * fx; var ry = -fz * fy; var rz = 1f - fz * fz
        val n = sqrt(rx * rx + ry * ry + rz * rz)
        if (n < 1e-3f) { head.roll = 0f; return }
        rx /= n; ry /= n; rz /= n
        val sx = fy * rz - fz * ry; val sy = fz * rx - fx * rz; val sz = fx * ry - fy * rx
        head.roll = Math.toDegrees(atan2((ux * sx + uy * sy + uz * sz).toDouble(), (ux * rx + uy * ry + uz * rz).toDouble())).toFloat()
    }
}
