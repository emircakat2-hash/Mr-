package com.nextvr.app.store

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** A web app added from the store. */
data class WebApp(val name: String, val url: String)

/**
 * Web apps of the store: the saved list (kept in the settings as text) and each site's own icon.
 * The icon is only fetched from the app's own site, and only after the user opened the app.
 */
object WebApps {
    fun parse(text: String): List<WebApp> = text.lineSequence().mapNotNull { line ->
        val i = line.indexOf('\t')
        if (i <= 0) return@mapNotNull null
        val url = line.substring(0, i)
        if (!url.startsWith("https://") && !url.startsWith("http://")) return@mapNotNull null
        WebApp(line.substring(i + 1).ifBlank { url }, url)
    }.distinctBy { it.url }.toList()

    fun serialize(list: List<WebApp>): String = list.joinToString("\n") { it.url + "\t" + it.name.replace('\n', ' ').replace('\t', ' ') }

    /** Sites that refuse a phone's WebView get a computer browser's identity. */
    private val DESKTOP_HOSTS = setOf("web.whatsapp.com", "open.spotify.com", "discord.com")
    fun needsDesktop(url: String): Boolean = Uri.parse(url).host?.removePrefix("www.") in DESKTOP_HOSTS

    private fun iconFile(c: Context, url: String): File {
        val host = Uri.parse(url).host?.removePrefix("www.") ?: url
        return File(c.filesDir, "webicons/" + host.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".png")
    }

    /** The icon saved on the phone, or null. Disk read: call off the main thread. */
    fun cachedIcon(c: Context, url: String): Bitmap? {
        val f = iconFile(c, url)
        if (!f.exists()) return null
        return runCatching { BitmapFactory.decodeFile(f.path) }.getOrNull()
    }

    fun deleteIcon(c: Context, url: String) { runCatching { iconFile(c, url).delete() } }

    /**
     * Network call (the app's own site only): apple-touch-icon, icon links of the page, /favicon.ico.
     * Saves and returns the icon, or null when the site has none. Call off the main thread.
     */
    fun fetchSiteIcon(c: Context, url: String): Bitmap? {
        cachedIcon(c, url)?.let { return it }
        val page = Uri.parse(url)
        val host = page.host ?: return null
        val origin = "${page.scheme ?: "https"}://$host"
        val candidates = ArrayList<String>()
        runCatching { readHead(url) }.getOrNull()?.let { candidates += iconLinks(it, url) }
        candidates += "$origin/apple-touch-icon.png"
        candidates += "$origin/favicon.ico"
        for (address in candidates.distinct()) {
            val bitmap = runCatching { download(address) }.getOrNull() ?: continue
            if (bitmap.width < 32 || bitmap.height < 32) continue
            runCatching {
                val f = iconFile(c, url)
                f.parentFile?.mkdirs()
                f.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
            return bitmap
        }
        return null
    }

    private const val AGENT = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    private fun connect(address: String): HttpURLConnection = (URL(address).openConnection() as HttpURLConnection).apply {
        connectTimeout = 8000; readTimeout = 8000; instanceFollowRedirects = true
        setRequestProperty("User-Agent", AGENT)
    }

    /** The first 256 KB of the page: enough for its <head>. */
    private fun readHead(address: String): String {
        val connection = connect(address)
        return try {
            connection.inputStream.use { input ->
                val buffer = ByteArray(262_144)
                var total = 0
                while (total < buffer.size) {
                    val n = input.read(buffer, total, buffer.size - total)
                    if (n < 0) break
                    total += n
                }
                String(buffer, 0, total, Charsets.UTF_8)
            }
        } finally { connection.disconnect() }
    }

    private fun download(address: String): Bitmap? {
        val connection = connect(address)
        return try { connection.inputStream.use { BitmapFactory.decodeStream(it) } } finally { connection.disconnect() }
    }

    /** Icon links of a page, touch icons and the largest first; svg is skipped (it cannot be decoded). */
    private fun iconLinks(html: String, base: String): List<String> {
        fun attr(tag: String, name: String): String? =
            Regex("""\b$name\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))""", RegexOption.IGNORE_CASE).find(tag)
                ?.let { it.groupValues[2].ifEmpty { it.groupValues[3].ifEmpty { it.groupValues[4] } } }
        val found = ArrayList<Pair<Int, String>>()
        for (match in Regex("""<link\b[^>]*>""", RegexOption.IGNORE_CASE).findAll(html)) {
            val tag = match.value
            val rel = attr(tag, "rel")?.lowercase() ?: continue
            if (!rel.contains("icon") || rel.contains("mask")) continue
            val href = attr(tag, "href")?.trim()?.takeIf { it.isNotEmpty() } ?: continue
            if (href.startsWith("data:") || href.substringBefore('?').endsWith(".svg", true)) continue
            val size = attr(tag, "sizes")?.substringBefore('x')?.toIntOrNull() ?: 0
            val score = size + if (rel.contains("apple-touch")) 1000 else 0
            val resolved = runCatching { URL(URL(base), href).toString() }.getOrNull() ?: continue
            found += score to resolved
        }
        return found.sortedByDescending { it.first }.map { it.second }
    }
}
