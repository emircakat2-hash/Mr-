package com.nextvr.app.ui
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nextvr.app.core.*
import com.nextvr.app.data.*
import com.nextvr.app.ui.theme.*

@Composable
fun StartScreen(store: SettingsStore, openSettings: () -> Unit) {
    val ctx = LocalContext.current
    val s by store.flow.collectAsState(initial = Settings())
    val items = remember { HardwareStatus.read(ctx) }
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("NEXTvr", style = MaterialTheme.typography.displaySmall, color = Accent)
        Text("Your World. Your Space.", style = MaterialTheme.typography.titleMedium)
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("VR Oturumu", style = MaterialTheme.typography.titleLarge)
                Text("Mod: ${s.vrMode}   •   Profil: ${s.performance}")
                Button(onClick = { ctx.startActivity(android.content.Intent(ctx, com.nextvr.app.VrActivity::class.java)) }, modifier = Modifier.fillMaxWidth()) { Text("VR Başlat") }
            }
        }
        Text("Sistem durumu", style = MaterialTheme.typography.titleMedium)
        items.forEach { StatusRow(it) }
        OutlinedButton(onClick = openSettings, modifier = Modifier.fillMaxWidth()) { Text("Ayarlar") }
    }
}

@Composable
private fun StatusRow(i: Item) {
    val col = when (i.level) { Level.READY -> Ok; Level.LIMITED -> Warn; Level.MISSING -> Err }
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(12.dp).background(col, CircleShape).align(androidx.compose.ui.Alignment.CenterVertically))
        Column { Text(i.label, style = MaterialTheme.typography.titleSmall); Text(i.detail, style = MaterialTheme.typography.bodySmall) }
    }
}
