package com.nextvr.app
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.nextvr.app.hand.HandTracker
import com.nextvr.app.browser.BrowserEngine
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.nextvr.app.ui.theme.NextVrTheme
import com.nextvr.app.vr.*

class VrActivity : ComponentActivity() {
    private val head = Head()
    private lateinit var tracker: HeadTracker
    private val hands by lazy { HandTracker(applicationContext) }
    private val browser by lazy { BrowserEngine(this) }
    private var req: Triple<Boolean, Boolean, String>? = null
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) applyHands() else hands.stop()
    }

    private fun applyHands() {
        val r = req ?: return
        if (!r.first) { hands.stop(); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) hands.start(this, r.second, r.third)
        else permLauncher.launch(Manifest.permission.CAMERA)
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        tracker = HeadTracker(this, head) { windowManager.defaultDisplay.rotation }
        val store = (application as NextVrApp).settings
        setContent { NextVrTheme { VrScreen(store, head, hands, browser, { en, front, prof -> req = Triple(en, front, prof); applyHands() }, { tracker.recenter() }, { finish() }) } }
    }
    override fun onResume() { super.onResume(); tracker.start(); browser.onResume(); if (req?.first == true) applyHands() }
    override fun onPause() { super.onPause(); tracker.stop(); hands.stop(); browser.onPause() }
    override fun onDestroy() { browser.stop(); super.onDestroy() }
}
