package com.nextvr.app.data
import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.*

private val Context.ds by preferencesDataStore("nextvr_settings")

data class Settings(
    val vrMode: String = "standard",
    val performance: String = "balanced",
    val dwellMs: Int = 1000,
    val firstRunDone: Boolean = false,
    val desktop: String = "",
    val handTracking: Boolean = false,
    val camera: String = "front",
    val pinchOn: Float = 0.28f,
    /** Web apps added from the store: one "url<TAB>name" per line. */
    val webApps: String = ""
)

class SettingsStore(private val c: Context) {
    private object K {
        val vrMode = stringPreferencesKey("vr_mode")
        val perf = stringPreferencesKey("perf")
        val dwell = intPreferencesKey("dwell_ms")
        val first = booleanPreferencesKey("first_run_done")
        val desktop = stringPreferencesKey("desktop_layout")
        val hand = booleanPreferencesKey("hand_tracking")
        val camera = stringPreferencesKey("hand_camera")
        val pinch = floatPreferencesKey("pinch_on")
        val webApps = stringPreferencesKey("web_apps")
    }
    val flow: Flow<Settings> = c.ds.data.map {
        Settings(it[K.vrMode] ?: "standard", it[K.perf] ?: "balanced", it[K.dwell] ?: 1000, it[K.first] ?: false, it[K.desktop] ?: "", it[K.hand] ?: false, it[K.camera] ?: "front", it[K.pinch] ?: 0.28f, it[K.webApps] ?: "")
    }
    suspend fun setVrMode(v: String) = c.ds.edit { it[K.vrMode] = v }
    suspend fun setPerformance(v: String) = c.ds.edit { it[K.perf] = v }
    suspend fun setDwell(v: Int) = c.ds.edit { it[K.dwell] = v }
    suspend fun setHand(v: Boolean) = c.ds.edit { it[K.hand] = v }
    suspend fun setCamera(v: String) = c.ds.edit { it[K.camera] = v }
    suspend fun setPinchOn(v: Float) = c.ds.edit { it[K.pinch] = v }
    suspend fun setDesktop(v: String) = c.ds.edit { it[K.desktop] = v }
    suspend fun setWebApps(v: String) = c.ds.edit { it[K.webApps] = v }
    suspend fun setFirstRunDone() = c.ds.edit { it[K.first] = true }
}
