package com.nextvr.app.hand
import kotlin.math.*

data class Pt(val x: Float, val y: Float)
data class HandData(val label: String, val pts: List<Pt>, val score: Float)

data class HandSnapshot(
    val visible: Boolean = false, val px: Float = .5f, val py: Float = .5f,
    val pinch: Boolean = false, val fist: Boolean = false, val palmCount: Int = 0,
    val hands: List<List<Pt>> = emptyList(), val ts: Long = 0L,
    // second hand (for two-hand interaction)
    val visible2: Boolean = false, val px2: Float = .5f, val py2: Float = .5f, val pinch2: Boolean = false,
    // calibration inputs (primary hand)
    val score: Float = 0f, val size: Float = 0f, val ratio: Float = 1f, val edge: Boolean = false
)

/** 1€ filter: strong smoothing when slow, low latency when fast. Time in seconds. */
class OneEuro(var minCutoff: Float, var beta: Float, private val dCutoff: Float = 1f) {
    private var first = true; private var xPrev = 0f; private var dxPrev = 0f; private var tPrev = 0f
    fun reset() { first = true }
    private fun alpha(c: Float, dt: Float): Float { val tau = 1f / (2f * PI.toFloat() * c); return 1f / (1f + tau / dt) }
    fun filter(x: Float, t: Float): Float {
        if (first) { first = false; xPrev = x; dxPrev = 0f; tPrev = t; return x }
        val dt = (t - tPrev).coerceAtLeast(1e-3f); tPrev = t
        val dx = (x - xPrev) / dt
        val ad = alpha(dCutoff, dt)
        val dxh = ad * dx + (1 - ad) * dxPrev; dxPrev = dxh
        val a = alpha(minCutoff + beta * abs(dxh), dt)
        val xh = a * x + (1 - a) * xPrev; xPrev = xh
        return xh
    }
}

private enum class G { NONE, PINCH, FIST, PALM, POINT }
private class HandState { var g = G.NONE; var cand = G.NONE; var candN = 0; var lastSeen = 0L }

/** Per-hand gesture state machine: hysteresis (pinch on/off), debounce (N frames), palm cooldown, loss grace. */
class GestureEngine {
    private val states = HashMap<String, HandState>()
    private val fx = OneEuro(1f, 8f); private val fy = OneEuro(1f, 8f)
    private val fx2 = OneEuro(1f, 8f); private val fy2 = OneEuro(1f, 8f)
    private var primaryKey: String? = null; private var secondKey: String? = null
    private var palmCount = 0; private var lastPalm = 0L
    var pinchOn = 0.28f; var pinchOff = 0.40f
    private val lossGraceMs = 180L; private val palmCooldownMs = 700L

    fun configure(profile: String) {
        val (c, b) = when (profile) { "lite" -> 1.2f to 10f; "precision" -> 1.8f to 16f; else -> 1.5f to 13f }
        for (f in listOf(fx, fy, fx2, fy2)) { f.minCutoff = c; f.beta = b }
    }

    private fun d(a: Pt, b: Pt, asp: Float) = hypot((a.x - b.x) * asp, a.y - b.y)
    private fun ratio(p: List<Pt>, asp: Float) = d(p[4], p[8], asp) / d(p[0], p[9], asp).coerceAtLeast(1e-3f)
    /** pointer = index tip, blending to thumb/index midpoint as the fingers close (continuous, no jump). */
    private fun pointer(p: List<Pt>, asp: Float): Pt {
        val t = ((ratio(p, asp) - 0.3f) / 0.4f).coerceIn(0f, 1f)
        val mx = (p[4].x + p[8].x) / 2f; val my = (p[4].y + p[8].y) / 2f
        return Pt(mx + (p[8].x - mx) * t, my + (p[8].y - my) * t)
    }

    fun update(hands: List<HandData>, ts: Long, aspect: Float): HandSnapshot {
        val seen = HashSet<String>()
        for (h in hands) {
            if (!seen.add(h.label)) continue
            val s = states.getOrPut(h.label) { HandState() }
            s.lastSeen = ts
            val p = h.pts
            val wrist = p[0]
            val ratio = ratio(p, aspect)
            val ext = listOf(8 to 6, 12 to 10, 16 to 14, 20 to 18).map { (tip, pip) -> d(p[tip], wrist, aspect) > d(p[pip], wrist, aspect) * 1.08f }
            val extCount = ext.count { it }
            val fistLike = extCount == 0 && d(p[8], wrist, aspect) < d(p[5], wrist, aspect) * 1.15f
            val pinching = !fistLike && (if (s.g == G.PINCH) ratio < pinchOff else ratio < pinchOn)
            val raw = when {
                pinching -> G.PINCH
                extCount == 0 -> G.FIST
                extCount == 4 -> G.PALM
                extCount == 1 && ext[0] -> G.POINT
                else -> G.NONE
            }
            if (raw == s.g) { s.candN = 0; s.cand = raw }
            else {
                if (raw == s.cand) s.candN++ else { s.cand = raw; s.candN = 1 }
                val need = if (raw == G.PINCH || s.g == G.PINCH) 1 else 2
                if (s.candN >= need) {
                    val busy = states.values.any { it !== s && (it.g == G.PINCH || it.g == G.FIST) } || s.g == G.PINCH || s.g == G.FIST
                    if (raw == G.PALM && !busy && ts - lastPalm > palmCooldownMs) { palmCount++; lastPalm = ts }
                    s.g = if (raw == G.PALM && busy) G.NONE else raw
                    s.candN = 0
                }
            }
        }
        states.entries.forEach { (k, s) -> if (k !in seen && ts - s.lastSeen > lossGraceMs) s.g = G.NONE }

        val prim = hands.firstOrNull { it.label == "Right" } ?: hands.firstOrNull()
        if (prim == null) return HandSnapshot(false, palmCount = palmCount, ts = ts)
        val sec = hands.firstOrNull { it !== prim }
        val sec2 = if (sec != null) sec else null
        if (primaryKey != prim.label) { primaryKey = prim.label; fx.reset(); fy.reset() }
        val sec2key = sec2?.let { it.label + hands.indexOf(it) }
        if (secondKey != sec2key) { secondKey = sec2key; fx2.reset(); fy2.reset() }
        val sec2s = ts / 1000f
        val pp = pointer(prim.pts, aspect)
        val ps = states[prim.label]
        val edge = prim.pts.any { it.x < 0.03f || it.x > 0.97f || it.y < 0.03f || it.y > 0.97f }
        var px2 = .5f; var py2 = .5f; var pinch2 = false
        if (sec2 != null) {
            val q = pointer(sec2.pts, aspect)
            px2 = fx2.filter(q.x, sec2s); py2 = fy2.filter(q.y, sec2s)
            pinch2 = if (sec2.label != prim.label) states[sec2.label]?.g == G.PINCH else ratio(sec2.pts, aspect) < pinchOn
        }
        return HandSnapshot(
            true, fx.filter(pp.x, sec2s), fy.filter(pp.y, sec2s),
            ps?.g == G.PINCH, ps?.g == G.FIST, palmCount, hands.map { it.pts }, ts,
            sec2 != null, px2, py2, pinch2,
            prim.score, d(prim.pts[0], prim.pts[9], aspect), ratio(prim.pts, aspect), edge)
    }
}
