package com.nextvr.app.vr

import android.graphics.Color as AColor

/** App tile colours of the VR home (taken from the NEXTvr-BE Horizon look; NEXTvr is dark only). */
object AppIcons {
    /** [tile] behind the glyph, [glyph] the glyph itself; both ARGB ints. */
    data class Palette(val tile: Int, val glyph: Int)

    private val HUES = mapOf("own:browser" to 212f, "own:store" to 28f, "own:settings" to 262f, "own:video" to 2f)

    /** A tonal pair in a hue of its own for [key]: a deep container with a light glyph. */
    fun palette(key: String): Palette {
        val hue = HUES[key] ?: ((key.hashCode() and 0x7fffffff) % 360).toFloat()
        return Palette(AColor.HSVToColor(floatArrayOf(hue, .55f, .30f)), AColor.HSVToColor(floatArrayOf(hue, .32f, 1f)))
    }

    /** Diagonal gradient (top-left to bottom-right) behind a white glyph, like the Horizon tiles. */
    val GRADIENTS: Map<String, Pair<Int, Int>> = mapOf(
        "own:browser" to (AColor.rgb(196, 160, 255) to AColor.rgb(84, 117, 230)),
        "own:video" to (AColor.rgb(255, 98, 88) to AColor.rgb(214, 20, 20)),
        "own:store" to (AColor.rgb(255, 167, 38) to AColor.rgb(230, 81, 0)),
        "own:settings" to (AColor.rgb(144, 164, 174) to AColor.rgb(69, 90, 100)),
        "own:win7" to (AColor.rgb(79, 195, 247) to AColor.rgb(21, 101, 192)),
        "env:0" to (AColor.rgb(84, 92, 106) to AColor.rgb(28, 32, 40)),
        "env:1" to (AColor.rgb(120, 100, 255) to AColor.rgb(36, 28, 92)),
        "env:2" to (AColor.rgb(236, 110, 173) to AColor.rgb(116, 72, 212)),
        "env:3" to (AColor.rgb(160, 174, 192) to AColor.rgb(74, 85, 104)),
    )
}
