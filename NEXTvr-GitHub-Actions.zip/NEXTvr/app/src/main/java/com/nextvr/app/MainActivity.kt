package com.nextvr.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.nextvr.app.ui.*
import com.nextvr.app.ui.theme.NextVrTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = (application as NextVrApp).settings
        setContent {
            NextVrTheme {
                var screen by remember { mutableStateOf("start") }
                if (screen == "start") StartScreen(store) { screen = "settings" }
                else SettingsScreen(store) { screen = "start" }
            }
        }
    }
}
