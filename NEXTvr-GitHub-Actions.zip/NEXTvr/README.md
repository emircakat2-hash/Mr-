# NEXTvr (sıfırdan) — Aşama 1-4

## El takibi modeli (isteğe bağlı)
MediaPipe model dosyasını şuraya koy:  app/src/main/assets/hand_landmarker.task
İlk derlemede Gradle modeli otomatik indirmeyi dener. İnternet/indirme erişimi yoksa derleme devam eder; ancak el takibi etkinleşmez. Modeli daha sonra `app/src/main/assets/hand_landmarker.task` konumuna ekleyebilirsin.
Resmî model: https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task

## Kontrol
- El imleci: işaret ucu (pinch yaklaşırken başparmakla orta nokta). Pinch = tıkla / pencere sürükle.
- Yumruk basılı tut = en üstteki pencereyi taşı. Açık avuç = Uygulamalar penceresi.
- İKİ EL: iki elle de pinch yap ve basılı tut. Eller açılıp kapanınca pencere büyür/küçülür, eller döndükçe pencere döner (±4° içinde otomatik dikleşir), orta nokta pencereyi taşır.
- Kalibrasyon: Ayarlar penceresi > Kalibrasyon > Başlat. Mesafe, ışık, kadraj, güven kontrol edilir; açık el ve pinch ölçülür, pinch eşiği kaydedilir.
- El kaybolunca gaze otomatik devreye girer.

## Aşama 5 — Tarayıcı (NEXTvr-BE'den uyarlandı)
- **Nasıl çalışır:** Her sekme gerçek bir WebView; uygulamanın özel sanal ekranında (1600x1000, 280 dpi) çalışır. Ekranın görüntüsü ImageReader ile alınır, bitmap olarak iki göze de çizilir. Gaze / el / dokunma girdileri sayfaya Android dokunma olayı olarak gönderilir.
- **Arayüz:** Chrome tarzı üst bar (sekme şeridi, ×, +, geri, ileri, yenile, adres alanı, ☆ yer imi, ⋮), yeni sekme sayfası (`assets/browser/home.html`: arama, saat, yer imleri, geçmiş, tercihler, kısayollar).
- **Kontrol:** Sayfada pinch = tıkla, pinch basılı tutup sürükle = kaydır. Gaze ile sayfada uzun bakış (en az 1,5 sn) = tıkla. Pencerenin sağındaki ▲ ▼ = kaydır. Adres alanına veya bir metin alanına dokununca VR klavyesi açılır (Türkçe Q).
- **Veri:** Yer imleri, geçmiş, kısayollar, masaüstü sitesi ve reklam engelleme ayarı telefonda saklanır. Açık sekmeler pencere kapatılınca hatırlanır.
- **Yok (sonraki aşamalar):** WebXR (Aşama 6), video merkezi (Aşama 9).
- **Dikkat:** Derleme ve gerçek cihaz testi yapılmadı. İlk iş Android Studio'da derle, sonra cihazda dene.

## Ana ekran: Dock + Kütüphane (NEXTvr-BE görünümü)
- **Dock** (dünyaya sabit, aşağıda): durum hapı (saat, Wi‑Fi, pil — gerçek değerler, dokununca Ayarlar), 4 sabit uygulama (Tarayıcı, Video, Mağaza, Ayarlar), 3 son kullanılan Android uygulaması, kütüphane düğmesi. Açık pencerenin altında nokta yanar.
- **Kütüphane**: dock'taki düğme veya açık avuç ile açılır. Solda bölüm ikonları (Tümü, Uygulamalar, Android, Dünyalar) ve sıralama; ortada 4-5-4 kademeli ikon ızgarası (sayfa başına 13); sağda sayfa noktaları. Dock'ta olmayan yüklü Android uygulamaları da burada görünür.
- Android uygulamasına dokunmak onu normal Android uygulaması olarak açar (VR penceresi olarak değil); geri dönünce VR devam eder.
- Henüz yok (BE'de var): profil, arama + klavye, geçiş (passthrough), hızlı ayarlar paneli, oda sürgüleri. Çalışmayan düğme eklenmedi.
- Dikkat: derlenmedi, cihazda denenmedi.

## Web uygulama mağazası (NEXTvr-BE App Store'dan)
- **Mağaza penceresi** (dock > Mağaza): 130'a yakın web uygulaması, kategoriler (Sosyal, Sohbet, Video, Müzik, Google, Üretkenlik, Tasarım, Geliştirici, Yapay zekâ, Oyun, Haber, Alışveriş, Seyahat, Eğitim, Araçlar). Üstte ‹ › ile filtre (Tümü, Yüklenenler, kategoriler), altta sayfa düğmeleri; sayfada 8 kart.
- **Kart**: simge, ad, kategori ve düğme. “Al” kütüphanedeki **Web** bölümüne ve Tümü'ne ekler, “Aç” uygulamayı tarayıcı penceresinde yeni sekmede açar, Yüklenenler filtresinde düğme “Sil” olur.
- Eklenenler ayarlarda (DataStore) saklanır. WhatsApp, Spotify ve Discord bilgisayar sitesi kimliğiyle açılır.
- Simge: eklenen uygulama önce renkli harf karosudur; ilk açılışta yalnızca o sitenin kendisinden (apple-touch-icon, sayfadaki icon bağlantıları, /favicon.ico) indirilir ve telefona kaydedilir. Üçüncü taraf favicon servisi kullanılmaz.
- Yok: uygulamayı kendi adresinizle ekleme formu, ayrı PWA penceresi (Aşama 7'nin kalanı).
- Dikkat: derlenmedi, cihazda denenmedi.

## Windows 7 (NEXTvr-BE'den taşındı)
- **Ne:** `assets/win7/win7.html`, tek dosyalık Windows 7 simülatörü (masaüstü, başlat menüsü, Hesap makinesi, Not Defteri, Paint, Komut İstemi, Nova Browser). BE'deki `assets/nexus/win7.html` dosyasının **değiştirilmemiş kopyası**.
- **Nasıl açılır:** Kütüphane > Uygulamalar > **Windows 7**. Tarayıcı penceresinde yerel sayfa olarak açılır (bilgisayar sitesi kimliğiyle); internet gerekmez. Tekrar açınca yeni sekme yerine var olan sekmeye geçer.
- **Güvenlik:** Üçüncü taraf sayfaya NEXTvr JavaScript köprüsü verilmez (`OWN_PAGES` artık yalnızca `assets/browser/`).
- **Ağ:** Sayfa kendiliğinden bağlantı kurmaz. Yalnızca Hava durumu / Döviz gadget'ı (open-meteo, open.er-api) ve içindeki Nova Browser/IE ile girilen siteler internete çıkar.
- **Dikkat:** APK yaklaşık 6 MB büyür. Derlenmedi, cihazda denenmedi (sayfa masaüstü Chromium'da açılıp denendi: hata yok, dış istek yok). Kaynağı Win7 Simu (Visnalize) sitesine dayanıyor; yayımlamadan önce lisans/izin durumunu doğrula.


## AndroidIDE / Ubuntu terminalinde derleme

1. ZIP'i AndroidIDE'nin erişebildiği bir klasöre çıkar.
2. AndroidIDE terminalinde proje klasörüne gir.
3. Aşağıdaki tek komutu çalıştır:

```bash
bash build-androidide.sh
```

Gereksinim: AndroidIDE'de JDK 17 seçili olmalı; Android SDK 34 ve ilk kurulum/bağımlılıklar için internet bağlantısı bulunmalı. AndroidIDE terminalinde `ANDROID_HOME` tanımlı olmalıdır.
Betik AndroidIDE'nin Gradle 8.7–8.x sürümünü kullanır; uygun sürüm yoksa Gradle 8.7'yi otomatik indirir. Gradle 9 kullanılmaz. İlk derlemede Gradle,
Android bağımlılıkları ve MediaPipe el takip modeli indirileceği için internet ve depolama gerekir.
Başarılı APK: `app/build/outputs/apk/debug/app-debug.apk`

Not: Bu paket AndroidIDE için yapılandırılmış kaynak projedir. İsteğin doğrultusunda burada APK derlemesi çalıştırılmadı; gerçek AndroidIDE/cihaz derleme testi yapılmış olduğu iddia edilmez.


### AndroidIDE sdkmanager notu
Derleme betiği artık `sdkmanager` komutunu otomatik çalıştırmaz. Bazı AndroidIDE kurulumlarındaki eski SDK Manager, JDK 17 ile `javax.xml.bind` hatası verebildiğinden SDK paketleri AndroidIDE'nin SDK Manager ekranından kurulmalıdır. Gerekli platform: Android 14 / API 34. Ardından terminalde `bash build-androidide.sh` çalıştır.
