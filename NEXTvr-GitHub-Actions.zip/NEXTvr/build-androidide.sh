#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
echo "=============================================="
echo " NEXTvr | AndroidIDE tek komut derleyici"
echo "=============================================="
if ! command -v java >/dev/null 2>&1; then echo "HATA: Java/JDK 17 bulunamadi. AndroidIDE'de JDK 17'yi etkinlestir."; exit 1; fi
JAVA_VERSION="$(java -version 2>&1 | sed -n '1s/.*version \"\(.*\)\".*/\1/p')"
JAVA_MAJOR="$(printf '%s' "$JAVA_VERSION" | awk -F. '{ if ($1 == 1) print $2; else print $1 }')"
if [[ -z "${JAVA_MAJOR:-}" ]] || (( JAVA_MAJOR < 17 )); then echo "HATA: JDK 17 veya uzeri gerekli. Bulunan: ${JAVA_VERSION:-bilinmiyor}"; exit 1; fi
echo "Java: $JAVA_VERSION"
GRADLE_BIN=""
if command -v gradle >/dev/null 2>&1; then
  GV="$(gradle --version 2>/dev/null | awk '/^Gradle / {print $2; exit}')"
  GM="$(printf '%s' "$GV" | cut -d. -f1)"; GN="$(printf '%s' "$GV" | cut -d. -f2)"
  if [[ "${GM:-0}" -eq 8 && "${GN:-0}" -ge 7 ]]; then GRADLE_BIN="$(command -v gradle)"; fi
fi
if [[ -z "$GRADLE_BIN" ]]; then
  DIST_ROOT="${GRADLE_USER_HOME:-$HOME/.gradle}/manual-dists"; DIST_DIR="$DIST_ROOT/gradle-8.7"; GRADLE_BIN="$DIST_DIR/bin/gradle"
  if [[ ! -x "$GRADLE_BIN" ]]; then
    mkdir -p "$DIST_ROOT"; ARCHIVE="$DIST_ROOT/gradle-8.7-bin.zip"
    echo "Gradle 8.7 indiriliyor (ilk kurulum)..."
    if command -v curl >/dev/null 2>&1; then curl -fL --retry 3 --retry-delay 2 https://services.gradle.org/distributions/gradle-8.7-bin.zip -o "$ARCHIVE"
    elif command -v wget >/dev/null 2>&1; then wget -O "$ARCHIVE" https://services.gradle.org/distributions/gradle-8.7-bin.zip
    else echo "HATA: curl veya wget bulunamadi."; exit 1; fi
    unzip -q -o "$ARCHIVE" -d "$DIST_ROOT"; rm -f "$ARCHIVE"
  fi
fi
echo "Gradle: $("$GRADLE_BIN" --version | awk '/^Gradle / {print $2; exit}')"
if [[ -z "${ANDROID_HOME:-}" && -n "${ANDROID_SDK_ROOT:-}" ]]; then export ANDROID_HOME="$ANDROID_SDK_ROOT"; fi
if [[ -z "${ANDROID_SDK_ROOT:-}" && -n "${ANDROID_HOME:-}" ]]; then export ANDROID_SDK_ROOT="$ANDROID_HOME"; fi
if [[ -z "${ANDROID_HOME:-}" ]]; then echo "HATA: Android SDK bulunamadi. AndroidIDE SDK ayarini kontrol et ve terminali yeniden ac."; exit 1; fi
# AndroidIDE'nin kendi SDK yonetimini kullan.
# Eski tools/bin/sdkmanager Java 17'de JAXB (javax.xml.bind) hatasi verebilir.
# SDK paketlerini burada kurmaya calismiyoruz; Gradle mevcut SDK'yi dogrudan kullanir.
if [[ ! -d "$ANDROID_HOME/platforms/android-34" ]]; then
  echo "HATA: Android SDK Platform 34 bulunamadi: $ANDROID_HOME/platforms/android-34"
  echo "AndroidIDE > SDK Manager bolumunden Android 14 / API 34 platformunu kur."
  exit 1
fi

echo "NEXTvr Debug APK derleniyor..."
"$GRADLE_BIN" --console=plain --max-workers=2 :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
if [[ -s "$APK" ]]; then echo; echo "DERLEME BASARILI: $APK"; else echo "HATA: APK olusmadi. Gradle hata mesajlarini kontrol et."; exit 1; fi
